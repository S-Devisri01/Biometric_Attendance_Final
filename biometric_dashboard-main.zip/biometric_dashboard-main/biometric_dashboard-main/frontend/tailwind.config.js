/** @type {import('tailwindcss').Config} */
export default {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],

}

module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // adjust this to match your project structure
    "./public/index.html"
  ],
  // rest of your Tailwind config
}