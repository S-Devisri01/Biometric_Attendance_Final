import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  Grid, 
  Paper, 
  Typography, 
  Divider, 
  Box, 
  Button 
} from '@mui/material';
import { 
  Dashboard as DashboardIcon,
  DateRange as DateRangeIcon,
  Timeline as TimelineIcon,
  CalendarMonth as CalendarMonthIcon
} from '@mui/icons-material';

const PrincipalAttendanceDashboard = () => {
  const [selectedView, setSelectedView] = useState('yearly');
  const [selectedDepartment, setSelectedDepartment] = useState('all');

  // Comprehensive College Attendance Data for 8 Engineering Departments
  const departmentData = [
    { 
      name: 'Computer Science', 
      totalStudents: 235,
      classAdvisor: 'Dr. Emily Rodriguez', 
      attendance: {
        daily: { 
          present: 212, 
          absent: 18, 
          late: 5, 
          percentage: 90.2,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 68240, 
          absent: 8520, 
          late: 2160, 
          percentage: 91.5,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Mechanical Engineering', 
      totalStudents: 210,
      classAdvisor: 'Prof. Michael Chen', 
      attendance: {
        daily: { 
          present: 190, 
          absent: 15, 
          late: 5, 
          percentage: 90.5,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },

        yearly: { 
          present: 61320, 
          absent: 7560, 
          late: 1920, 
          percentage: 92.1,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Electrical Engineering', 
      totalStudents: 195,
      classAdvisor: 'Dr. Sarah Thompson', 
      attendance: {
        daily: { 
          present: 175, 
          absent: 15, 
          late: 5, 
          percentage: 89.7,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 56880, 
          absent: 8820, 
          late: 1800, 
          percentage: 90.2,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Civil Engineering', 
      totalStudents: 180,
      classAdvisor: 'Prof. David Wilson', 
      attendance: {
        daily: { 
          present: 162, 
          absent: 12, 
          late: 6, 
          percentage: 90.0,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 58320, 
          absent: 7200, 
          late: 1728, 
          percentage: 92.3,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Chemical Engineering', 
      totalStudents: 170,
      classAdvisor: 'Dr. Jennifer Martinez', 
      attendance: {
        daily: { 
          present: 153, 
          absent: 12, 
          late: 5, 
          percentage: 90.0,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 55440, 
          absent: 7560, 
          late: 1800, 
          percentage: 91.2,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Aerospace Engineering', 
      totalStudents: 160,
      classAdvisor: 'Prof. Robert Lee', 
      attendance: {
        daily: { 
          present: 144, 
          absent: 10, 
          late: 6, 
          percentage: 90.0,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 52560, 
          absent: 6240, 
          late: 2160, 
          percentage: 92.5,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Biomedical Engineering', 
      totalStudents: 145,
      classAdvisor: 'Dr. Sophia Wang', 
      attendance: {
        daily: { 
          present: 131, 
          absent: 10, 
          late: 4, 
          percentage: 90.3,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 47520, 
          absent: 5840, 
          late: 1440, 
          percentage: 91.8,
          period: '2024 Academic Year'
        }
      }
    },
    { 
      name: 'Environmental Engineering', 
      totalStudents: 135,
      classAdvisor: 'Prof. Daniel Kim', 
      attendance: {
        daily: { 
          present: 122, 
          absent: 8, 
          late: 5, 
          percentage: 90.4,
          date: '2024-03-26'
        },
        weekly: { 
          present: 385, 
          absent: 28, 
          late: 7, 
          percentage: 93.2,
          period: 'Mar 20-26, 2024'
        },
        monthly: { 
          present: 1540, 
          absent: 112, 
          late: 28, 
          percentage: 94.3,
          period: 'March 2024'
        },
        yearly: { 
          present: 49140, 
          absent: 5400, 
          late: 1800, 
          percentage: 92.0,
          period: '2024 Academic Year'
        }
      }
    }
  ];

  // Color Scheme
  const COLORS = [
    'rgba(54, 162, 235, 0.8)',   // Blue
    'rgba(255, 99, 132, 0.8)',   // Pink
    'rgba(75, 192, 192, 0.8)',   // Teal
    'rgba(255, 206, 86, 0.8)',   // Yellow
    'rgba(153, 102, 255, 0.8)',  // Purple
    'rgba(255, 159, 64, 0.8)',   // Orange
    'rgba(199, 199, 199, 0.8)',  // Grey
    'rgba(83, 202, 115, 0.8)'    // Green
  ];

  // Overall College Attendance
  const overallAttendance = {
    totalStudents: departmentData.reduce((sum, dept) => sum + dept.totalStudents, 0),
    present: departmentData.reduce((sum, dept) => sum + dept.attendance.yearly.present, 0),
    absent: departmentData.reduce((sum, dept) => sum + dept.attendance.yearly.absent, 0),
    late: departmentData.reduce((sum, dept) => sum + dept.attendance.yearly.late, 0),
    percentage: departmentData.reduce((sum, dept) => sum + dept.attendance.yearly.percentage, 0) / departmentData.length
  };

  // Pie Chart Data
  const pieData = [
    { 
      name: 'Present', 
      value: overallAttendance.present, 
      percentage: (overallAttendance.present / (overallAttendance.totalStudents * 365)) * 100 
    },
    { 
      name: 'Absent', 
      value: overallAttendance.absent, 
      percentage: (overallAttendance.absent / (overallAttendance.totalStudents * 365)) * 100 
    },
    { 
      name: 'Late', 
      value: overallAttendance.late, 
      percentage: (overallAttendance.late / (overallAttendance.totalStudents * 365)) * 100 
    }
  ];

  // Render Department Card
  const renderDepartmentCard = (dept, index) => {
    const attendance = dept.attendance[selectedView];
    return (
      <Grid item xs={12} md={6} key={index}>
        <Paper 
          elevation={4} 
          sx={{ 
            p: 3, 
            borderRadius: 3, 
            background: `linear-gradient(135deg, ${COLORS[index]} 0%, ${COLORS[(index + 1) % COLORS.length]} 100%)`,
            color: 'white'
          }}
        >
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6" sx={{ fontWeight: "bold" }}>
              {dept.name} Department
            </Typography>
             <Box display="flex" gap={1}>
                          {['daily', 'weekly', 'monthly', 'yearly'].map((view) => (
                            <Button 
                              key={view}
                              variant={selectedView === view ? 'contained' : 'outlined'}
                              color="inherit"
                              size="small"
                              onClick={() => setSelectedView(view)}
                              startIcon={
                                view === 'daily' ? <DashboardIcon /> :
                                view === 'weekly' ? <DateRangeIcon /> :
                                view === 'monthly' ? <CalendarMonthIcon /> :
                                <TimelineIcon />
                              }
                            >
                              {view.charAt(0).toUpperCase() + view.slice(1)}
                            </Button>
                          ))}
                        </Box>
          </Box>
          <Divider sx={{ mb: 2, bgcolor: 'white' }} />
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Box>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>Advisor Details</Typography>
                <Typography variant="body2">
                  Name: {dept.classAdvisor}
                </Typography>
                <Typography variant="body2">
                  Total Students: {dept.totalStudents}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6}>
              <Box>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>Attendance Period</Typography>
                <Typography variant="body2">
                  Period: {attendance.period || attendance.date}
                </Typography>
                <Typography variant="body2">
                  Overall Percentage: {attendance.percentage.toFixed(1)}%
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12}>
              <Box>
                <Typography variant="body1" sx={{ fontWeight: 'bold', mb: 1 }}>Detailed Attendance Breakdown</Typography>
                <Grid container spacing={1}>
                  <Grid item xs={4}>
                    <Typography variant="body2">
                      Present: {attendance.present} 
                      ({((attendance.present / dept.totalStudents) * 100).toFixed(1)}%)
                    </Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography variant="body2">
                      Absent: {attendance.absent} 
                      ({((attendance.absent / dept.totalStudents) * 100).toFixed(1)}%)
                    </Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography variant="body2">
                      Late: {attendance.late} 
                      ({((attendance.late / dept.totalStudents) * 100).toFixed(1)}%)
                    </Typography>
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Grid>
    );
  };

  // Render Overall College Summary
  const renderCollegeSummary = () => {
    return (
      <Paper 
        sx={{ 
          mt: 3, 
          p: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 2, textAlign: 'center' }}>
          College Attendance Overview
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Box textAlign="center">
              <Typography variant="h6">Total Students</Typography>
              <Typography variant="h4">{overallAttendance.totalStudents}</Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <Typography variant="h6">Total Present</Typography>
              <Typography variant="h4">{overallAttendance.present}</Typography>
              <Typography variant="body2">
                ({((overallAttendance.present / (overallAttendance.totalStudents * 365)) * 100).toFixed(1)}%)
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <Typography variant="h6">Overall Attendance</Typography>
              <Typography variant="h4">{overallAttendance.percentage.toFixed(1)}%</Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>
    );
  };

  // Render Pie Chart with Detailed Information
  const renderPieChart = () => {
    return (
      <Paper 
        sx={{ 
          mt: 4, 
          p: 4, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)' 
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, color: 'white', textAlign: 'center' }}>
          College Attendance Distribution
        </Typography>
        <Box display="flex" justifyContent="center" alignItems="center">
          <ResponsiveContainer width="60%" height={400}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={120}
                fill="#8884d8"
                dataKey="value"
                label={({ name, value, percentage }) => 
                  `${name}: ${value} (${percentage.toFixed(1)}%)`
                }
              >
                {pieData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[index % COLORS.length]} 
                  />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value, name, props) => [
                  `${value} (${props.payload.percentage.toFixed(1)}%)`, 
                  name
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
          <Box ml={4} color="white">
            {pieData.map((entry, index) => (
              <Box key={entry.name} display="flex" alignItems="center" mb={2}>
                <Box 
                  width={20} 
                  height={20} 
                  bgcolor={COLORS[index % COLORS.length]} 
                  mr={2} 
                />
                <Typography>
                  {entry.name}: {entry.value} ({entry.percentage.toFixed(1)}%)
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Paper>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-1 p-8 overflow-y-auto">
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          College Attendance Dashboard
        </Typography>

        {/* College Summary */}
        {renderCollegeSummary()}

        {/* Department Cards Grid */}
        <Grid container spacing={3} sx={{ mt: 3 }}>
          {departmentData.map(renderDepartmentCard)}
        </Grid>

        {/* Overall Pie Chart */}
        {renderPieChart()}
      </div>
    </div>
  );
};

export default PrincipalAttendanceDashboard;