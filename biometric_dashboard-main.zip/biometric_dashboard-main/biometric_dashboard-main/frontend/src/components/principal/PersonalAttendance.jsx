import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { 
  Grid, 
  Paper, 
  Typography, 
  Divider, 
  Box, 
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  FormControl,
  Select,
  MenuItem
} from '@mui/material';
import { 
  Dashboard as DashboardIcon,
  School as SchoolIcon,
  People as PeopleIcon,
  Warning as WarningIcon,
  AccountBalance as AccountBalanceIcon
} from '@mui/icons-material';

const MultiCollegePrincipalDashboard = () => {
  // State to manage selected college
  const [selectedCollege, setSelectedCollege] = useState('Engineering');

  // Comprehensive Institutional Data
  const institutionalAttendanceData = {
    Engineering: {
      departments: [
        { name: 'Agri', totalStudents: 120, present: 105, absent: 15, attendancePercentage: 87.5 },
        { name: 'ECE', totalStudents: 210, present: 185, absent: 25, attendancePercentage: 88.1 },
        { name: 'Mechanical', totalStudents: 180, present: 156, absent: 24, attendancePercentage: 86.7 },
        { name: 'Biomedical', totalStudents: 150, present: 132, absent: 18, attendancePercentage: 88.0 },
        { name: 'CSE', totalStudents: 235, present: 203, absent: 32, attendancePercentage: 86.4 },
        { name: 'IT', totalStudents: 140, present: 122, absent: 18, attendancePercentage: 87.1 },
        { name: 'AI&DS', totalStudents: 100, present: 88, absent: 12, attendancePercentage: 88.0 },
        { name: 'Cyber Security', totalStudents: 90, present: 80, absent: 10, attendancePercentage: 88.9 }
      ],
      faculty: { totalFaculty: 68, present: 62, absent: 6, attendancePercentage: 91.2 }
    },
    Pharmacy: {
      departments: [
        { name: 'D Pharm', totalStudents: 80, present: 72, absent: 8, attendancePercentage: 90.0 },
        { name: 'B Pharm', totalStudents: 120, present: 108, absent: 12, attendancePercentage: 90.0 },
        { name: 'Pharm D', totalStudents: 60, present: 54, absent: 6, attendancePercentage: 90.0 },
        { name: 'M Pharm', totalStudents: 40, present: 36, absent: 4, attendancePercentage: 90.0 }
      ],
      faculty: { totalFaculty: 32, present: 30, absent: 2, attendancePercentage: 93.8 }
    },
    Nursing: {
      departments: [
        { name: 'Nursing', totalStudents: 200, present: 180, absent: 20, attendancePercentage: 90.0 }
      ],
      faculty: { totalFaculty: 25, present: 23, absent: 2, attendancePercentage: 92.0 }
    },
    'Medical Science & Research': {
      departments: [
        { name: 'Cardiac Technology', totalStudents: 50, present: 45, absent: 5, attendancePercentage: 90.0 },
        { name: 'Radiology & Imaging', totalStudents: 60, present: 54, absent: 6, attendancePercentage: 90.0 },
        { name: 'Operation Theatre Tech', totalStudents: 40, present: 36, absent: 4, attendancePercentage: 90.0 },
        { name: 'Optometry', totalStudents: 45, present: 41, absent: 4, attendancePercentage: 91.1 },
        { name: 'Medical Laboratory', totalStudents: 55, present: 50, absent: 5, attendancePercentage: 90.9 },
        { name: 'Cardiac Pulmonary Tech', totalStudents: 35, present: 32, absent: 3, attendancePercentage: 91.4 },
        { name: 'Health Inspector Diploma', totalStudents: 30, present: 27, absent: 3, attendancePercentage: 90.0 }
      ],
      faculty: { totalFaculty: 40, present: 37, absent: 3, attendancePercentage: 92.5 }
    }
  };

  // Color Scheme
  const COLORS = [
    'rgba(54, 162, 235, 0.8)',   // Blue
    'rgba(255, 99, 132, 0.8)',   // Pink
    'rgba(75, 192, 192, 0.8)',   // Teal
    'rgba(255, 206, 86, 0.8)',   // Yellow
    'rgba(153, 102, 255, 0.8)',  // Purple
    'rgba(255, 159, 64, 0.8)'    // Orange
  ];

  // Render College Selector
  const renderCollegeSelector = () => {
    return (
      <FormControl fullWidth sx={{ mb: 2 }}>
        <Select
          value={selectedCollege}
          onChange={(e) => setSelectedCollege(e.target.value)}
          sx={{ 
            bgcolor: 'white', 
            '&:hover': { bgcolor: 'white' },
            '.MuiSelect-select': { py: 1.5 }
          }}
        >
          {Object.keys(institutionalAttendanceData).map((college) => (
            <MenuItem key={college} value={college}>{college}</MenuItem>
          ))}
        </Select>
      </FormControl>
    );
  };

  // Render Institution Overview
  const renderInstitutionOverview = () => {
    const collegeData = institutionalAttendanceData[selectedCollege];
    const totalStudents = collegeData.departments.reduce((sum, dept) => sum + dept.totalStudents, 0);
    const totalPresent = collegeData.departments.reduce((sum, dept) => sum + dept.present, 0);
    const overallStudentAttendance = (totalPresent / totalStudents * 100).toFixed(1);

    return (
      <Paper 
        sx={{ 
          p: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          {selectedCollege} College Attendance Overview
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Box textAlign="center">
              <AccountBalanceIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Total Students</Typography>
              <Typography variant="h4">{totalStudents}</Typography>
              <Typography variant="body2">
                Across {collegeData.departments.length} Departments
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <SchoolIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Faculty</Typography>
              <Typography variant="h4">{collegeData.faculty.totalFaculty}</Typography>
              <Typography variant="body2">
                Attendance: {collegeData.faculty.attendancePercentage.toFixed(1)}%
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <WarningIcon sx={{ fontSize: 50, mb: 1, color: 'yellow' }} />
              <Typography variant="h6">Low Attendance</Typography>
              <Typography variant="h4">
                {collegeData.departments.filter(dept => 
                  (dept.present / dept.totalStudents * 100) < 75
                ).length}
              </Typography>
              <Typography variant="body2">
                Departments Below 75%
              </Typography>
            </Box>
          </Grid>
        </Grid>
        <Divider sx={{ my: 2, bgcolor: 'white' }} />
        <Typography variant="h6" sx={{ textAlign: 'center' }}>
          Overall Student Attendance: {overallStudentAttendance}%
        </Typography>
      </Paper>
    );
  };

  // Render Departmental Comparison
  const renderDepartmentalComparison = () => {
    const collegeData = institutionalAttendanceData[selectedCollege];
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(135deg, rgba(54, 162, 235, 0.8) 0%, rgba(255, 99, 132, 0.8) 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          {selectedCollege} Departmental Attendance
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={collegeData.departments}>
            <XAxis dataKey="name" stroke="white" />
            <YAxis stroke="white" domain={[80, 95]} />
            <Tooltip />
            <Bar dataKey="attendancePercentage" fill="rgba(255,255,255,0.7)">
              {collegeData.departments.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]} 
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Paper>
    );
  };

  // Render Low Attendance Departments
  const renderLowAttendanceDepartments = () => {
    const collegeData = institutionalAttendanceData[selectedCollege];
    const lowAttendanceDepartments = collegeData.departments.filter(
      dept => (dept.present / dept.totalStudents * 100) < 75
    );

    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #ff416c 0%, #ff4b2b 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          {selectedCollege} Low Attendance Departments
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ color: 'white' }}>Department</TableCell>
                <TableCell sx={{ color: 'white' }}>Total Students</TableCell>
                <TableCell sx={{ color: 'white' }}>Present</TableCell>
                <TableCell sx={{ color: 'white' }}>Attendance %</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {lowAttendanceDepartments.length > 0 ? (
                lowAttendanceDepartments.map((dept, index) => (
                  <TableRow key={index}>
                    <TableCell sx={{ color: 'white' }}>{dept.name}</TableCell>
                    <TableCell sx={{ color: 'white' }}>{dept.totalStudents}</TableCell>
                    <TableCell sx={{ color: 'white' }}>{dept.present}</TableCell>
                    <TableCell sx={{ 
                      color: 'yellow',
                      fontWeight: 'bold'
                    }}>
                      {(dept.present / dept.totalStudents * 100).toFixed(1)}%
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} sx={{ color: 'white', textAlign: 'center' }}>
                    No Departments with Low Attendance
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-1 p-8 overflow-y-auto">
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          Multi-College Principal Attendance Dashboard
        </Typography>

        {/* College Selector */}
        {renderCollegeSelector()}

        {/* Institution Overview */}
        {renderInstitutionOverview()}

        {/* Departmental Comparison */}
        {renderDepartmentalComparison()}

        {/* Low Attendance Departments */}
        {renderLowAttendanceDepartments()}
      </div>
    </div>
  );
};

export default MultiCollegePrincipalDashboard;