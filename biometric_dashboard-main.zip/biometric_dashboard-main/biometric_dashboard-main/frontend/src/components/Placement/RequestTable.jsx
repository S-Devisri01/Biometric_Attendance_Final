import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  Chip,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  Tooltip,
  Snackbar,
  Alert,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from '@mui/material';
import { 
  Visibility, 
  Check, 
  Close, 
  PictureAsPdf,
  Image,
  Description,
  Work
} from '@mui/icons-material';

// Initial Placement Request Data Structure
const initialPlacementRequests = [
  {
    id: 1,
    studentName: 'John Doe',
    studentId: 'S12345',
    department: 'Computer Science',
    companyName: 'Tech Giants Inc.',
    packageOffered: '₹8,00,000 LPA',
    profileRole: 'Software Developer',
    attachments: [
      { 
        name: 'resume.pdf', 
        type: 'application/pdf', 
        url: '/path/to/resume.pdf' 
      },
      {
        name: 'offer_letter.pdf',
        type: 'application/pdf',
        url: '/path/to/offer_letter.pdf'
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-10' },
      { stage: 'Class Advisor', status: 'Completed', approvedBy: 'Dr. Emily Rodriguez', date: '2024-10-11' },
      { stage: 'Placement Officer', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  },
  {
    id: 2,
    studentName: 'Jane Smith',
    studentId: 'S12346',
    department: 'Electronics',
    companyName: 'Innovation Solutions',
    packageOffered: '₹7,50,000 LPA',
    profileRole: 'Electronics Engineer',
    attachments: [
      { 
        name: 'company_profile.pdf', 
        type: 'application/pdf', 
        url: '/path/to/company_profile.pdf' 
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-12' },
      { stage: 'Class Advisor', status: 'Completed', approvedBy: 'Dr. Sarah Thompson', date: '2024-10-13' },
      { stage: 'Placement Officer', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  },
  {
    id: 3,
    studentName: 'Alex Johnson',
    studentId: 'S12347',
    department: 'Mechanical Engineering',
    companyName: 'Global Manufacturing',
    packageOffered: '₹7,00,000 LPA',
    profileRole: 'Manufacturing Engineer',
    attachments: [
      { 
        name: 'internship_details.pdf', 
        type: 'application/pdf', 
        url: '/path/to/internship_details.pdf' 
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-15' },
      { stage: 'Class Advisor', status: 'Completed', approvedBy: 'Dr. Rachel Green', date: '2024-10-16' },
      { stage: 'Placement Officer', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  }
];

const PlacementOfficerRequestManagement = () => {
  const [requests, setRequests] = useState(initialPlacementRequests);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [openModal, setOpenModal] = useState(false);
  const [filePreview, setFilePreview] = useState(null);
  const [departmentFilter, setDepartmentFilter] = useState('All');
  
  // Notification State
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const handleRequestAction = (requestId, action) => {
    const updatedRequests = requests.map(request => {
      if (request.id === requestId) {
        const updatedWorkflow = request.workflow.map((workflowStep) => {
          if (workflowStep.stage === 'Placement Officer' && workflowStep.status === 'Pending') {
            return {
              ...workflowStep,
              status: action,
              approvedBy: 'Placement Officer', // Replace with actual user in real implementation
              date: new Date().toISOString().split('T')[0]
            };
          }
          return workflowStep;
        });

        return { ...request, workflow: updatedWorkflow };
      }
      return request;
    });

    setRequests(updatedRequests);

    // Show Notification
    setNotification({
      open: true,
      message: `Request ${action === 'Completed' ? 'Verified' : 'Rejected'}`,
      severity: action === 'Completed' ? 'success' : 'error'
    });

    // Close the modal
    setOpenModal(false);
  };

  const handleCloseNotification = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setNotification({ ...notification, open: false });
  };

  const handleFilePreview = (file) => {
    setFilePreview({
      name: file.name,
      type: file.type,
      url: file.url
    });
  };

  const renderFilePreviewModal = () => (
    <Dialog 
      open={!!filePreview} 
      onClose={() => setFilePreview(null)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>{filePreview?.name}</DialogTitle>
      <DialogContent>
        {filePreview?.type === 'application/pdf' ? (
          <iframe 
            src={filePreview.url} 
            width="100%" 
            height="500px" 
            title="PDF Preview"
          />
        ) : filePreview?.type.startsWith('image/') ? (
          <img 
            src={filePreview.url} 
            alt="Attachment" 
            style={{ maxWidth: '100%', maxHeight: '500px', objectFit: 'contain' }} 
          />
        ) : (
          <Typography>Unable to preview this file type</Typography>
        )}
      </DialogContent>
      <DialogActions>
        <Button 
          color="primary" 
          variant="contained"
          href={filePreview?.url}
          target="_blank"
          download
        >
          Download File
        </Button>
        <Button onClick={() => setFilePreview(null)} color="secondary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );

  const renderAttachmentIcon = (fileType) => {
    if (fileType === 'application/pdf') return <PictureAsPdf />;
    if (fileType.startsWith('image/')) return <Image />;
    return <Description />;
  };

  const renderRequestDetailsModal = () => (
    <Dialog 
      open={openModal} 
      onClose={() => setOpenModal(false)}
      maxWidth="md"
      fullWidth
    >
      {selectedRequest && (
        <>
          <DialogTitle>
            Placement Request: {selectedRequest.studentName}
            <Typography variant="subtitle2">
              <Work sx={{ verticalAlign: 'middle', mr: 1 }} />
              {selectedRequest.profileRole}
            </Typography>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="h6">Student Information</Typography>
                <Box>
                  <Typography>Name: {selectedRequest.studentName}</Typography>
                  <Typography>Student ID: {selectedRequest.studentId}</Typography>
                  <Typography>Department: {selectedRequest.department}</Typography>
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="h6">Placement Details</Typography>
                <Box>
                  <Typography>Company: {selectedRequest.companyName}</Typography>
                  <Typography>Role: {selectedRequest.profileRole}</Typography>
                  <Typography>Package: {selectedRequest.packageOffered}</Typography>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6">Workflow Status</Typography>
                <Box>
                  {selectedRequest.workflow.map((step, index) => (
                    <Grid container key={index} spacing={2} sx={{ mb: 1 }}>
                      <Grid item xs={4}>
                        <Typography>{step.stage}</Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Chip 
                          label={step.status} 
                          color={
                            step.status === 'Completed' ? 'success' : 
                            step.status === 'Pending' ? 'warning' : 
                            step.status === 'Awaiting' ? 'default' : 'error'
                          }
                          size="small"
                        />
                      </Grid>
                      <Grid item xs={4}>
                        <Typography variant="body2">
                          {step.approvedBy ? `By ${step.approvedBy}` : 'Awaiting Approval'}
                        </Typography>
                      </Grid>
                    </Grid>
                  ))}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6">Attachments</Typography>
                <Box display="flex" gap={2}>
                  {selectedRequest.attachments.map(attachment => (
                    <Button 
                      key={attachment.name} 
                      variant="outlined" 
                      startIcon={renderAttachmentIcon(attachment.type)}
                      onClick={() => handleFilePreview(attachment)}
                    >
                      {attachment.name}
                    </Button>
                  ))}
                </Box>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button 
              color="primary" 
              startIcon={<Check />}
              onClick={() => handleRequestAction(selectedRequest.id, 'Completed')}
              disabled={
                selectedRequest.workflow.find(
                  step => step.stage === 'Placement Officer' && step.status === 'Pending'
                ) ? false : true
              }
            >
              Verify
            </Button>
            <Button 
              color="error" 
              startIcon={<Close />}
              onClick={() => handleRequestAction(selectedRequest.id, 'Rejected')}
              disabled={
                selectedRequest.workflow.find(
                  step => step.stage === 'Placement Officer' && step.status === 'Pending'
                ) ? false : true
              }
            >
              Reject
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );

  // Filter requests
  const filteredRequests = requests.filter(request => 
    departmentFilter === 'All' || request.department === departmentFilter
  );

  return (
    <Box sx={{ p: 4, minHeight: '100vh' }}>
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          Placement Request Management
        </Typography>

        {/* Department Filter Dropdown */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
          <FormControl variant="outlined" sx={{ minWidth: 200 }}>
            <InputLabel>Filter by Department</InputLabel>
            <Select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              label="Filter by Department"
            >
              <MenuItem value="All">All Departments</MenuItem>
              <MenuItem value="Computer Science">Computer Science</MenuItem>
              <MenuItem value="Electronics">Electronics</MenuItem>
              <MenuItem value="Mechanical Engineering">Mechanical Engineering</MenuItem>
            </Select>
          </FormControl>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Student Name</TableCell>
                <TableCell>Department</TableCell>
                <TableCell>Company</TableCell>
                <TableCell>Package</TableCell>
                <TableCell>Current Stage</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredRequests.map(request => {
                const currentStage = request.workflow.find(step => step.stage === 'Placement Officer' && step.status === 'Pending');
                return (
                  <TableRow key={request.id}>
                    <TableCell>{request.studentName}</TableCell>
                    <TableCell>{request.department}</TableCell>
                    <TableCell>{request.companyName}</TableCell>
                    <TableCell>{request.packageOffered}</TableCell>
                    <TableCell>
                      <Chip 
                        label={currentStage ? 'Pending' : 'Processed'} 
                        color={currentStage ? 'warning' : 'success'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      <Tooltip title="View Placement Request">
                        <IconButton 
                          color="primary"
                          onClick={() => {
                            setSelectedRequest(request);
                            setOpenModal(true);
                          }}
                        >
                          <Visibility />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Notification Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseNotification} 
          severity={notification.severity} 
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>

      {renderRequestDetailsModal()}
      {renderFilePreviewModal()}
    </Box>
  );
};

export default PlacementOfficerRequestManagement;