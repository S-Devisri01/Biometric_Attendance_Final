import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line
} from 'recharts';
import { 
  Grid, 
  Paper, 
  Typography, 
  Box, 
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  Chip
} from '@mui/material';
import { 
  Work as WorkIcon,
  AttachMoney as MoneyIcon,
  School as SchoolIcon,
  BusinessCenter as BusinessIcon
} from '@mui/icons-material';

const PlacementDashboard = () => {
  // Placement Detailed Data
  const placementData = {
    totalStudents: 600,
    placedStudents: 485,
    placementPercentage: 80.8,
    totalPackageValue: 3200,
    averagePackage: 6.6,
    departments: [
      { 
        name: 'Computer Science', 
        totalStudents: 235,
        placedStudents: 195,
        placementPercentage: 83.0,
        averageSalary: 7.5,
        highestPackage: 15.5
      },
      { 
        name: 'Electronics', 
        totalStudents: 210,
        placedStudents: 170,
        placementPercentage: 81.0,
        averageSalary: 6.8,
        highestPackage: 12.3
      },
      { 
        name: 'Mechanical', 
        totalStudents: 180,
        placedStudents: 140,
        placementPercentage: 77.8,
        averageSalary: 6.2,
        highestPackage: 11.0
      },
      { 
        name: 'Civil', 
        totalStudents: 150,
        placedStudents: 120,
        placementPercentage: 80.0,
        averageSalary: 5.5,
        highestPackage: 9.5
      }
    ],
    topRecruiters: [
      { name: 'TCS', students: 65, percentage: 13.4, averagePackage: 6.0 },
      { name: 'Infosys', students: 55, percentage: 11.3, averagePackage: 5.8 },
      { name: 'Wipro', students: 45, percentage: 9.3, averagePackage: 5.5 },
      { name: 'Amazon', students: 40, percentage: 8.2, averagePackage: 12.5 }
    ]
  };

  // Top Placed Students Details
  const topPlacedStudents = [
    { 
      name: 'John Doe', 
      department: 'Computer Science',
      company: 'Amazon',
      package: 15.5,
      skills: ['Machine Learning', 'Cloud Computing', 'Python']
    },
    { 
      name: 'Jane Smith', 
      department: 'Electronics', 
      company: 'Google', 
      package: 12.3,
      skills: ['IoT', 'Embedded Systems', 'AI']
    },
    { 
      name: 'Mike Johnson', 
      department: 'Mechanical', 
      company: 'Mercedes-Benz', 
      package: 11.0,
      skills: ['Automotive Design', 'CAD', 'Manufacturing']
    },
    { 
      name: 'Sarah Williams', 
      department: 'Civil', 
      company: 'L&T', 
      package: 9.5,
      skills: ['Structural Engineering', 'Project Management']
    }
  ];

  // Color Palette
  const COLORS = [
    '#3498db', // Blue
    '#e74c3c', // Red
    '#2ecc71', // Green
    '#f39c12'  // Orange
  ];

  // Render Department Placement Analysis
  const renderDepartmentPlacementAnalysis = () => {
    return (
      <Paper 
        sx={{ 
          p: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Department Placement Analysis
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={placementData.departments}>
            <XAxis dataKey="name" stroke="white" />
            <YAxis stroke="white" domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="placementPercentage" name="Placement %" fill="rgba(255,255,255,0.7)">
              {placementData.departments.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
        <Grid container spacing={2} sx={{ mt: 2 }}>
          {placementData.departments.map((dept, index) => (
            <Grid item xs={3} key={dept.name} sx={{ textAlign: 'center' }}>
              <Typography variant="subtitle1" sx={{ color: COLORS[index % COLORS.length] }}>
                {dept.name}
              </Typography>
              <Typography variant="body2">
                Placed: {dept.placementPercentage}% | Avg Package: {dept.averageSalary} LPA
              </Typography>
            </Grid>
          ))}
        </Grid>
      </Paper>
    );
  };

  // Render Top Placed Students
  const renderTopPlacedStudents = () => {
    return (
      <Paper sx={{ p: 3, mt: 3, borderRadius: 2 }}>
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Top Placed Students
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Department</TableCell>
                <TableCell>Company</TableCell>
                <TableCell>Package (LPA)</TableCell>
                <TableCell>Skills</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {topPlacedStudents.map((student, index) => (
                <TableRow key={index}>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>{student.department}</TableCell>
                  <TableCell>{student.company}</TableCell>
                  <TableCell>
                    <Chip 
                      label={`${student.package} LPA`} 
                      color="primary" 
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Box display="flex" gap={1}>
                      {student.skills.map((skill, skillIndex) => (
                        <Chip 
                          key={skillIndex} 
                          label={skill} 
                          size="small" 
                          color="secondary" 
                        />
                      ))}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    );
  };

  // Render Salary Package Distribution
  const renderSalaryPackageDistribution = () => {
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #11998e 0%, #38ef7d 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Salary Package Distribution
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={placementData.topRecruiters}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="averagePackage"
            >
              {placementData.topRecruiters.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
        <Grid container spacing={2} sx={{ mt: 2 }}>
          {placementData.topRecruiters.map((recruiter, index) => (
            <Grid item xs={3} key={recruiter.name} sx={{ textAlign: 'center' }}>
              <Typography variant="subtitle1" sx={{ color: COLORS[index % COLORS.length] }}>
                {recruiter.name}
              </Typography>
              <Typography variant="body2">
                {recruiter.students} Students | Avg Package: {recruiter.averagePackage} LPA
              </Typography>
            </Grid>
          ))}
        </Grid>
      </Paper>
    );
  };

  return (
    <div className="bg-gray-50 min-h-screen p-8">
      <Typography 
        variant="h4" 
        gutterBottom 
        sx={{ 
          textAlign: 'center', 
          fontWeight: 'bold', 
          color: '#2c3e50', 
          mb: 4 
        }}
      >
        Placement Officer Dashboard
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={3}>
          <Paper 
            sx={{ 
              p: 3, 
              borderRadius: 2, 
              background: 'linear-gradient(to right, #ff416c 0%, #ff4b2b 100%)',
              color: 'white',
              height: '100%'
            }}
          >
            <Box textAlign="center">
              <SchoolIcon sx={{ fontSize: 50, mb: 2 }} />
              <Typography variant="h6">Total Students</Typography>
              <Typography variant="h4">{placementData.totalStudents}</Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={3}>
          <Paper 
            sx={{ 
              p: 3, 
              borderRadius: 2, 
              background: 'linear-gradient(to right, #11998e 0%, #38ef7d 100%)',
              color: 'white',
              height: '100%'
            }}
          >
            <Box textAlign="center">
              <WorkIcon sx={{ fontSize: 50, mb: 2 }} />
              <Typography variant="h6">Placed Students</Typography>
              <Typography variant="h4">{placementData.placedStudents}</Typography>
              <Typography variant="body2">
                Placement Rate: {placementData.placementPercentage}%
              </Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={3}>
          <Paper 
            sx={{ 
              p: 3, 
              borderRadius: 2, 
              background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
              color: 'white',
              height: '100%'
            }}
          >
            <Box textAlign="center">
              <MoneyIcon sx={{ fontSize: 50, mb: 2 }} />
              <Typography variant="h6">Total Package Value</Typography>
              <Typography variant="h4">
                {placementData.totalPackageValue} LPA
              </Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={3}>
          <Paper 
            sx={{ 
              p: 3, 
              borderRadius: 2, 
              background: 'linear-gradient(to right, #f12711 0%, #f5af19 100%)',
              color: 'white',
              height: '100%'
            }}
          >
            <Box textAlign="center">
              <BusinessIcon sx={{ fontSize: 50, mb: 2 }} />
              <Typography variant="h6">Average Package</Typography>
              <Typography variant="h4">
                {placementData.averagePackage} LPA
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Department Placement Analysis */}
      {renderDepartmentPlacementAnalysis()}

      {/* Salary Package Distribution */}
      {renderSalaryPackageDistribution()}

      {/* Top Placed Students */}
      {renderTopPlacedStudents()}
    </div>
  );
};

export default PlacementDashboard;