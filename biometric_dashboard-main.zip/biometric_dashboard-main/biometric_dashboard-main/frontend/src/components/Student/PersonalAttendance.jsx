import React, { useState } from 'react';
import { 
  Paper, 
  Typography, 
  Box, 
  Button, 
  Grid,
  Divider
} from '@mui/material';
import { 
  PieChart, 
  Pie, 
  ResponsiveContainer, 
  Tooltip as RechartsTooltip, 
  Cell,
  Legend 
} from 'recharts';
import { 
  CalendarToday as CalendarTodayIcon,
  DateRange as DateRangeIcon,
  Timeline as TimelineIcon,
  CalendarMonth as CalendarMonthIcon
} from '@mui/icons-material';

const PersonalAttendance = () => {
  const [selectedView, setSelectedView] = useState('monthly');

  // Mock User Details
  const userDetails = {
    name: 'John Doe',
    studentId: 'CSE2024-0042',
    semester: '4th Semester',
    department: 'Computer Science & Engineering',
    classAdvisor: 'Dr. Emily Rodriguez'
  };

  // Comprehensive Attendance Data
  const attendanceData = {
    daily: {
      present: 1,
      absent: 0,
      percentage: 100,
      date: '2024-03-26'
    },
    weekly: {
      present: 5,
      absent: 2,
      percentage: 71.4,
      period: 'Mar 20-26, 2024'
    },
    monthly: {
      present: 22,
      absent: 8,
      percentage: 73.3,
      period: 'March 2024'
    },
    yearly: {
      present: 264,
      absent: 96,
      percentage: 73.3,
      period: '2024 Academic Year'
    }
  };

  // Pie Chart Data
  const pieData = [
    { 
      name: 'Present', 
      value: attendanceData[selectedView].present, 
      color: 'rgba(75, 192, 192, 0.8)' 
    },
    { 
      name: 'Absent', 
      value: attendanceData[selectedView].absent, 
      color: 'rgba(255, 99, 132, 0.8)' 
    }
  ];

  // Detailed Attendance Log
  const attendanceLog = [
    { date: '2024-03-01', status: 'Present' },
    { date: '2024-03-02', status: 'Absent' },
    { date: '2024-03-03', status: 'Present' },
    { date: '2024-03-04', status: 'Present' },
    { date: '2024-03-05', status: 'Absent' },
    { date: '2024-03-06', status: 'Present' },
    // Add more log entries as needed
  ];

  // Handle Cancel Button
  const handleCancel = () => {
    window.history.back();
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-1 p-8 overflow-y-auto">
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          Personal Attendance Dashboard
        </Typography>

        {/* User Details and Summary */}
        <Paper 
          sx={{ 
            p: 3, 
            mb: 3, 
            borderRadius: 2, 
            background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
            color: 'white'
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography variant="h6">{userDetails.name}</Typography>
              <Typography variant="body2">
                Student ID: {userDetails.studentId}
              </Typography>
              <Typography variant="body2">
                Department: {userDetails.department}
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2">
                Semester: {userDetails.semester}
              </Typography>
              <Typography variant="body2">
                Class Advisor: {userDetails.classAdvisor}
              </Typography>
            </Grid>
          </Grid>
        </Paper>

        {/* Attendance Summary Card */}
        <Paper 
          elevation={4} 
          sx={{ 
            p: 3, 
            borderRadius: 3, 
            background: 'linear-gradient(135deg, rgba(54, 162, 235, 0.8) 0%, rgba(255, 99, 132, 0.8) 100%)',
            color: 'white'
          }}
        >
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6" sx={{ fontWeight: "bold" }}>
              Attendance Overview
            </Typography>
            <Box display="flex" gap={1}>
              {['daily', 'weekly', 'monthly', 'yearly'].map((view) => (
                <Button 
                  key={view}
                  variant={selectedView === view ? 'contained' : 'outlined'}
                  color="inherit"
                  size="small"
                  onClick={() => setSelectedView(view)}
                  startIcon={
                    view === 'daily' ? <CalendarTodayIcon /> :
                    view === 'weekly' ? <DateRangeIcon /> :
                    view === 'monthly' ? <CalendarMonthIcon /> :
                    <TimelineIcon />
                  }
                >
                  {view.charAt(0).toUpperCase() + view.slice(1)}
                </Button>
              ))}
            </Box>
          </Box>
          <Divider sx={{ mb: 2, bgcolor: 'white' }} />
          
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, value, percent }) => 
                      `${name}: ${value} (${(percent * 100).toFixed(1)}%)`
                    }
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </Grid>
            <Grid item xs={6}>
              <Box>
                <Typography variant="body1" sx={{ fontWeight: 'bold', mb: 1 }}>
                  Attendance Details
                </Typography>
                <Typography variant="body2">
                  Period: {attendanceData[selectedView].period || attendanceData[selectedView].date}
                </Typography>
                <Typography variant="body2">
                  Attendance Percentage: {attendanceData[selectedView].percentage.toFixed(1)}%
                </Typography>
                <Typography variant="body2">
                  Present: {attendanceData[selectedView].present}
                </Typography>
                <Typography variant="body2">
                  Absent: {attendanceData[selectedView].absent}
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Paper>

        {/* Attendance Log Section */}
        <Paper 
          sx={{ 
            mt: 3, 
            p: 3, 
            borderRadius: 2, 
            background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
            color: 'white'
          }}
        >
          <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
            Detailed Attendance Log
          </Typography>
          <Box sx={{ maxHeight: 300, overflowY: "auto" }}>
            {attendanceLog.map((entry, index) => (
              <Box
                key={index}
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "8px",
                  borderBottom: "1px solid rgba(255,255,255,0.2)",
                }}
              >
                <Typography variant="body2" color="inherit">
                  {entry.date}
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    color: entry.status === "Present" ? "lightgreen" : "lightcoral",
                    fontWeight: "bold",
                  }}
                >
                  {entry.status}
                </Typography>
              </Box>
            ))}
          </Box>
        </Paper>

        {/* Cancel Button */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
          {/* <Button 
            variant="contained" 
            color="primary" 
            onClick={handleCancel}
          >
            Back to Dashboard
          </Button> */}
        </Box>
      </div>
    </div>
  );
};

export default PersonalAttendance;