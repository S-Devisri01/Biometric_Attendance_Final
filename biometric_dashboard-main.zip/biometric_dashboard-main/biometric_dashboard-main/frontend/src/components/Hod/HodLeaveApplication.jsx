import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Typography, 
  TextField, 
  Button, 
  MenuItem, 
  Paper, 
  Alert, 
  Snackbar,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select
} from '@mui/material';
import { 
  Event as EventIcon, 
  Person as PersonIcon, 
  Email as EmailIcon, 
  Description as DescriptionIcon 
} from '@mui/icons-material';

// Initial data with more comprehensive leave balances
const initialLeaveBalance = {
  casualLeave: 10,
  sickLeave: 7,
  festivalLeave: 3,
  od: 5,
};

const alreadyTakenLeave = {
  casualLeave: 3,
  sickLeave: 2,
  festivalLeave: 1,
  od: 2,
};

const leaveTypes = [
  { value: "Leave", label: "Leave" },
  { value: "OD", label: "On Duty" },
];

const leaveReasons = [
  { value: "Casual Leave", label: "Casual Leave" },
  { value: "Sick Leave", label: "Sick Leave" },
  { value: "Festival Leave", label: "Festival Leave" },
  { value: "Other", label: "Other" },
];

function LeaveApplicationForm() {
  const [formData, setFormData] = useState({
    name: "",
    sinNumber: "",
    email: "",
    reason: "",
    otherReason: "",
    odReason: "",
    startDate: "",
    endDate: "",
    duration: 0,
  });

  const [leaveType, setLeaveType] = useState("");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState("success");
  const [leaveBalance, setLeaveBalance] = useState({
    casualLeave: initialLeaveBalance.casualLeave - alreadyTakenLeave.casualLeave,
    sickLeave: initialLeaveBalance.sickLeave - alreadyTakenLeave.sickLeave,
    festivalLeave: initialLeaveBalance.festivalLeave - alreadyTakenLeave.festivalLeave,
    od: initialLeaveBalance.od - alreadyTakenLeave.od,
  });
  const [isFormSubmittedToday, setIsFormSubmittedToday] = useState(false);

  // Calculate minimum start date (today)
  const today = new Date().toISOString().split('T')[0];

  const calculateDuration = (startDate, endDate) => {
    if (!startDate || !endDate) return 0;
    const start = new Date(startDate);
    const end = new Date(endDate);
    // Calculate business days
    let duration = 0;
    while (start <= end) {
      // Skip weekends
      if (start.getDay() !== 0 && start.getDay() !== 6) {
        duration++;
      }
      start.setDate(start.getDate() + 1);
    }
    return duration;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value,
    }));

    if (name === "leaveType") {
      setLeaveType(value);
    }

    if (name === "reason") {
      setFormData(prevData => ({
        ...prevData,
        reason: value,
        otherReason: value === "Other" ? prevData.otherReason : "",
      }));
    }

    if (name === "startDate" || name === "endDate") {
      const duration = calculateDuration(
        name === "startDate" ? value : formData.startDate,
        name === "endDate" ? value : formData.endDate
      );
      setFormData(prevData => ({
        ...prevData,
        duration: duration,
      }));
    }
  };

  const validateForm = () => {
    // More comprehensive validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const sinRegex = /^\d{9}$/; // Assuming 9-digit SIN number

    if (!formData.name.trim()) {
      setSnackbarMessage("Please enter your full name.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return false;
    }

    if (!sinRegex.test(formData.sinNumber)) {
      setSnackbarMessage("Please enter a valid 9-digit SIN number.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return false;
    }

    if (!emailRegex.test(formData.email)) {
      setSnackbarMessage("Please enter a valid email address.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return false;
    }

    if (!formData.startDate || !formData.endDate) {
      setSnackbarMessage("Please select both start and end dates.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return false;
    }

    if (new Date(formData.startDate) > new Date(formData.endDate)) {
      setSnackbarMessage("End date must be after start date.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return false;
    }

    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isFormSubmittedToday) {
      setSnackbarMessage("You have already submitted a form today.");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
      return;
    }

    if (!validateForm()) {
      return;
    }

    // Check leave balance
    if (leaveType === "Leave") {
      const requiredLeave = formData.duration;
      let availableLeave = 0;

      switch (formData.reason) {
        case "Casual Leave":
          availableLeave = leaveBalance.casualLeave;
          break;
        case "Sick Leave":
          availableLeave = leaveBalance.sickLeave;
          break;
        case "Festival Leave":
          availableLeave = leaveBalance.festivalLeave;
          break;
        default:
          availableLeave = 0;
      }

      if (requiredLeave > availableLeave) {
        setSnackbarMessage(`Insufficient ${formData.reason} balance.`);
        setSnackbarSeverity("error");
        setSnackbarOpen(true);
        return;
      }
    }

    // Submission success
    setSnackbarMessage(`${leaveType} form successfully submitted.`);
    setSnackbarSeverity("success");
    setSnackbarOpen(true);
    setIsFormSubmittedToday(true);
  };

  return (
    <Container 
      maxWidth="lg" 
      sx={{ 
        flexGrow: 1, 
        p: 3, 
        
        minHeight: '90vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }} 
    >
      <Card 
        sx={{ 
          maxWidth: 1000, 
          width: '100%', 
          borderRadius: 4, 
          boxShadow: '0 15px 30px rgba(0,0,0,0.15)',
          overflow: 'hidden'
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Typography 
            variant="h4" 
            gutterBottom 
            sx={{ 
              textAlign: 'center', 
              color: '#00838f', 
              fontWeight: 'bold',
              mb: 4,
              borderBottom: '3px solid #00838f',
              pb: 0
            }}
          >
            Leave Application
          </Typography>

          <Grid container spacing={3}>
            {/* Leave Type Selection */}
            <Grid item xs={12}>
              <FormControl fullWidth variant="outlined">
                <InputLabel>Form Type</InputLabel>
                <Select
                  name="leaveType"
                  value={leaveType}
                  onChange={handleChange}
                  label="Form Type"
                >
                  {leaveTypes.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            {/* Personal Information */}
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                variant="outlined"
                required
                InputProps={{
                  startAdornment: <PersonIcon color="action" sx={{ mr: 1 }} />
                }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Sin Number"
                name="sinNumber"
                value={formData.sinNumber}
                onChange={handleChange}
                variant="outlined"
                required
                inputProps={{ maxLength: 9 }}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                variant="outlined"
                required
                InputProps={{
                  startAdornment: <EmailIcon color="action" sx={{ mr: 1 }} />
                }}
              />
            </Grid>

            {/* Leave Details */}
            {leaveType === "Leave" && (
              <>
                <Grid item xs={12}>
                  <FormControl fullWidth variant="outlined">
                    <InputLabel>Leave Reason</InputLabel>
                    <Select
                      name="reason"
                      value={formData.reason}
                      onChange={handleChange}
                      label="Leave Reason"
                    >
                      {leaveReasons.map((option) => (
                        <MenuItem key={option.value} value={option.value}>
                          {option.label}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                {(formData.reason === "Other" || 
                  formData.reason === "Casual Leave" || 
                  formData.reason === "Sick Leave" || 
                  formData.reason === "Festival Leave") && (
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Detailed Reason"
                      name="otherReason"
                      value={formData.otherReason}
                      onChange={handleChange}
                      variant="outlined"
                      required
                      multiline
                      rows={3}
                      InputProps={{
                        startAdornment: <DescriptionIcon color="action" sx={{ mr: 1 }} />
                      }}
                    />
                  </Grid>
                )}
              </>
            )}

            {leaveType === "OD" && (
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="On Duty Reason"
                  name="odReason"
                  value={formData.odReason}
                  onChange={handleChange}
                  variant="outlined"
                  required
                  multiline
                  rows={3}
                  InputProps={{
                    startAdornment: <DescriptionIcon color="action" sx={{ mr: 1 }} />
                  }}
                />
              </Grid>
            )}

            {/* Date Selection */}
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Start Date"
                name="startDate"
                type="date"
                value={formData.startDate}
                onChange={handleChange}
                variant="outlined"
                InputLabelProps={{ shrink: true }}
                inputProps={{ min: today }}
                required
                InputProps={{
                  startAdornment: <EventIcon color="action" sx={{ mr: 1 }} />
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="End Date"
                name="endDate"
                type="date"
                value={formData.endDate}
                onChange={handleChange}
                variant="outlined"
                InputLabelProps={{ shrink: true }}
                inputProps={{ 
                  min: formData.startDate || today 
                }}
                required
                InputProps={{
                  startAdornment: <EventIcon color="action" sx={{ mr: 1 }} />
                }}
              />
            </Grid>

            {/* Duration */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Total Duration (Business Days)"
                name="duration"
                value={formData.duration}
                variant="outlined"
                disabled
              />
            </Grid>

            {/* Leave Balance */}
            <Grid item xs={12}>
              <Paper 
                elevation={2} 
                sx={{ 
                  p: 2, 
                  background: '#e0f2f1', 
                  borderRadius: 2 
                }}
              >
                <Typography variant="h6" sx={{ color: '#00695c', mb: 2 }}>
                  Current Leave Balance
                </Typography>
                {leaveType === "Leave" && formData.reason && (
                  <Grid container spacing={2}>
                    <Grid item xs={4}>
                      <Typography variant="body1" color="primary">
                        Casual Leave: {leaveBalance.casualLeave}
                      </Typography>
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="body1" color="primary">
                        Sick Leave: {leaveBalance.sickLeave}
                      </Typography>
                    </Grid>
                    <Grid item xs={4}>
                      <Typography variant="body1" color="primary">
                        Festival Leave: {leaveBalance.festivalLeave}
                      </Typography>
                    </Grid>
                  </Grid>
                )}
                {leaveType === "OD" && (
                  <Typography variant="body1" color="primary">
                    OD Balance: {leaveBalance.od}
                  </Typography>
                )}
              </Paper>
            </Grid>

            {/* Submit Button */}
            <Grid item xs={12}>
              <Button
                fullWidth
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                sx={{ 
                  py: 1.5, 
                  fontSize: '1rem',
                  background: 'linear-gradient(45deg, #00796b 30%, #009688 90%)',
                  '&:hover': {
                    background: 'linear-gradient(45deg, #00796b 10%, #009688 90%)'
                  }
                }}
              >
                Submit Leave Application
              </Button>
            </Grid>
          </Grid>

          {/* Snackbar for Notifications */}
          <Snackbar
            open={snackbarOpen}
            autoHideDuration={4000}
            onClose={() => setSnackbarOpen(false)}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
          >
            <Alert
              onClose={() => setSnackbarOpen(false)}
              severity={snackbarSeverity}
              sx={{ width: '100%' }}
            >
              {snackbarMessage}
            </Alert>
          </Snackbar>
        </CardContent>
      </Card>
    </Container>
  );
}

export default LeaveApplicationForm;