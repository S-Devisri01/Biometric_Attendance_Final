import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell,
  BarChart,
  Bar
} from 'recharts';
import { 
  Grid, 
  Paper, 
  Typography, 
  Divider, 
  Box, 
  Button,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell
} from '@mui/material';
import { 
  Dashboard as DashboardIcon,
  People as PeopleIcon,
  Assessment as AssessmentIcon,
  Warning as WarningIcon,
  School as SchoolIcon
} from '@mui/icons-material';

const HODAttendanceDashboard = () => {
  const [selectedView, setSelectedView] = useState('department');

  // Department-level Attendance Data
  const departmentAttendanceData = {
    CSE: { 
      totalStudents: 235,
      present: 203,
      absent: 32,
      attendancePercentage: 86.4,
      years: [
        { name: '1st Year', present: 53, total: 62, percentage: 85.5 },
        { name: '2nd Year', present: 51, total: 58, percentage: 87.9 },
        { name: '3rd Year', present: 44, total: 55, percentage: 80.0 },
        { name: '4th Year', present: 55, total: 60, percentage: 91.7 }
      ]
    },
    faculty: {
      totalFaculty: 18,
      present: 16,
      absent: 2,
      attendancePercentage: 88.9
    }
  };

  // Low Attendance Students
  const lowAttendanceStudents = [
    { 
      name: 'John Doe', 
      studentId: 'CSE2024-0042', 
      year: '3rd Year', 
      attendancePercentage: 65.3 
    },
    { 
      name: 'Jane Smith', 
      studentId: 'CSE2024-0053', 
      year: '2nd Year', 
      attendancePercentage: 68.7 
    },
    { 
      name: 'Mike Johnson', 
      studentId: 'CSE2024-0031', 
      year: '4th Year', 
      attendancePercentage: 70.2 
    }
  ];

  // Attendance Trend Data
  const attendanceTrendData = [
    { month: 'Jan', studentAttendance: 82.5, facultyAttendance: 89.3 },
    { month: 'Feb', studentAttendance: 84.2, facultyAttendance: 90.1 },
    { month: 'Mar', studentAttendance: 86.4, facultyAttendance: 88.9 }
  ];

  // Color Scheme
  const COLORS = [
    'rgba(54, 162, 235, 0.8)',   // Blue
    'rgba(255, 99, 132, 0.8)',   // Pink
    'rgba(75, 192, 192, 0.8)',   // Teal
    'rgba(255, 206, 86, 0.8)'    // Yellow
  ];

  // Render Department Overview
  const renderDepartmentOverview = () => {
    const { CSE, faculty } = departmentAttendanceData;
    return (
      <Paper 
        sx={{ 
          p: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Department Attendance Overview
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Box textAlign="center">
              <PeopleIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Students</Typography>
              <Typography variant="h4">{CSE.totalStudents}</Typography>
              <Typography variant="body2">
                Attendance: {CSE.attendancePercentage.toFixed(1)}%
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <SchoolIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Faculty</Typography>
              <Typography variant="h4">{faculty.totalFaculty}</Typography>
              <Typography variant="body2">
                Attendance: {faculty.attendancePercentage.toFixed(1)}%
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <WarningIcon sx={{ fontSize: 50, mb: 1, color: 'yellow' }} />
              <Typography variant="h6">Low Attendance</Typography>
              <Typography variant="h4">{lowAttendanceStudents.length}</Typography>
              <Typography variant="body2">
                Students Below 75%
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Paper>
    );
  };

  // Render Attendance by Year
  const renderYearlyAttendance = () => {
    const { CSE } = departmentAttendanceData;
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(135deg, rgba(54, 162, 235, 0.8) 0%, rgba(255, 99, 132, 0.8) 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Yearly Attendance Breakdown
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={CSE.years}>
            <XAxis dataKey="name" stroke="white" />
            <YAxis stroke="white" />
            <Tooltip />
            <Bar dataKey="percentage" fill="rgba(255,255,255,0.7)">
              {CSE.years.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]} 
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Paper>
    );
  };

  // Render Low Attendance Students
  const renderLowAttendanceStudents = () => {
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #ff416c 0%, #ff4b2b 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Low Attendance Students
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ color: 'white' }}>Name</TableCell>
                <TableCell sx={{ color: 'white' }}>Student ID</TableCell>
                <TableCell sx={{ color: 'white' }}>Year</TableCell>
                <TableCell sx={{ color: 'white' }}>Attendance %</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {lowAttendanceStudents.map((student, index) => (
                <TableRow key={index}>
                  <TableCell sx={{ color: 'white' }}>{student.name}</TableCell>
                  <TableCell sx={{ color: 'white' }}>{student.studentId}</TableCell>
                  <TableCell sx={{ color: 'white' }}>{student.year}</TableCell>
                  <TableCell sx={{ 
                    color: student.attendancePercentage < 75 ? 'yellow' : 'white',
                    fontWeight: 'bold'
                  }}>
                    {student.attendancePercentage.toFixed(1)}%
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    );
  };

  // Render Attendance Trend
  const renderAttendanceTrend = () => {
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #11998e 0%, #38ef7d 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Attendance Trend
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={attendanceTrendData}>
            <XAxis dataKey="month" stroke="white" />
            <YAxis stroke="white" />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="studentAttendance" 
              stroke="#fff" 
              strokeWidth={3}
              name="Student Attendance"
            />
            <Line 
              type="monotone" 
              dataKey="facultyAttendance" 
              stroke="#ffd700" 
              strokeWidth={3}
              name="Faculty Attendance"
            />
          </LineChart>
        </ResponsiveContainer>
      </Paper>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-1 p-8 overflow-y-auto">
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          HOD Attendance Dashboard
        </Typography>

        {/* Department Overview */}
        {renderDepartmentOverview()}

        {/* Yearly Attendance Breakdown */}
        {renderYearlyAttendance()}

        {/* Low Attendance Students */}
        {renderLowAttendanceStudents()}

        {/* Attendance Trend */}
        {renderAttendanceTrend()}
      </div>
    </div>
  );
};

export default HODAttendanceDashboard;