import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  Chip,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  Tooltip,
  Snackbar,
  Alert,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from '@mui/material';
import { 
  Visibility, 
  Check, 
  Close, 
  PictureAsPdf,
  Image,
  Description,
  Person
} from '@mui/icons-material';

// Initial Class Advisor Request Data Structure
const initialClassAdvisorRequests = [
  {
    id: 1,
    studentName: 'John Doe',
    studentId: 'S12345',
    department: 'Computer Science',
    semester: '5th Semester',
    requestType: 'Leave',
    reason: 'Medical Emergency',
    startDate: '2024-10-15',
    endDate: '2024-10-20',
    attachments: [
      { 
        name: 'medical_certificate.pdf', 
        type: 'application/pdf', 
        url: '/path/to/medical_certificate.pdf' 
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-10' },
      { stage: 'Class Advisor', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  },
  {
    id: 2,
    studentName: 'Jane Smith',
    studentId: 'S12346',
    department: 'Electronics',
    semester: '4th Semester',
    requestType: 'Internship',
    companyName: 'Tech Innovations Ltd',
    duration: '3 Months',
    attachments: [
      { 
        name: 'offer_letter_draft.pdf', 
        type: 'application/pdf', 
        url: '/path/to/offer_letter_draft.pdf' 
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-12' },
      { stage: 'Class Advisor', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  },
  {
    id: 3,
    studentName: 'Alex Johnson',
    studentId: 'S12347',
    department: 'Mechanical Engineering',
    semester: '6th Semester',
    requestType: 'On Duty',
    reason: 'Technical Conference',
    startDate: '2024-11-05',
    endDate: '2024-11-07',
    attachments: [
      { 
        name: 'conference_invite.pdf', 
        type: 'application/pdf', 
        url: '/path/to/conference_invite.pdf' 
      }
    ],
    workflow: [
      { stage: 'Student', status: 'Completed', approvedBy: 'Student', date: '2024-10-20' },
      { stage: 'Class Advisor', status: 'Pending', approvedBy: null, date: null },
      { stage: 'Head of Department', status: 'Awaiting', approvedBy: null, date: null }
    ]
  }
];

const ClassAdvisorRequestManagement = () => {
  const [requests, setRequests] = useState(initialClassAdvisorRequests);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [openModal, setOpenModal] = useState(false);
  const [filePreview, setFilePreview] = useState(null);
  const [requestFilter, setRequestFilter] = useState('All');
  
  // Notification State
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const handleRequestAction = (requestId, action) => {
    const updatedRequests = requests.map(request => {
      if (request.id === requestId) {
        const updatedWorkflow = request.workflow.map((workflowStep) => {
          if (workflowStep.stage === 'Class Advisor' && workflowStep.status === 'Pending') {
            return {
              ...workflowStep,
              status: action,
              approvedBy: 'Class Advisor', // Replace with actual user in real implementation
              date: new Date().toISOString().split('T')[0]
            };
          }
          return workflowStep;
        });

        return { ...request, workflow: updatedWorkflow };
      }
      return request;
    });

    setRequests(updatedRequests);

    // Show Notification
    setNotification({
      open: true,
      message: `Request ${action === 'Completed' ? 'Recommended' : 'Not Recommended'}`,
      severity: action === 'Completed' ? 'success' : 'error'
    });

    // Close the modal
    setOpenModal(false);
  };

  const handleCloseNotification = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setNotification({ ...notification, open: false });
  };

  const handleFilePreview = (file) => {
    setFilePreview({
      name: file.name,
      type: file.type,
      url: file.url
    });
  };

  const renderFilePreviewModal = () => (
    <Dialog 
      open={!!filePreview} 
      onClose={() => setFilePreview(null)}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>{filePreview?.name}</DialogTitle>
      <DialogContent>
        {filePreview?.type === 'application/pdf' ? (
          <iframe 
            src={filePreview.url} 
            width="100%" 
            height="500px" 
            title="PDF Preview"
          />
        ) : filePreview?.type.startsWith('image/') ? (
          <img 
            src={filePreview.url} 
            alt="Attachment" 
            style={{ maxWidth: '100%', maxHeight: '500px', objectFit: 'contain' }} 
          />
        ) : (
          <Typography>Unable to preview this file type</Typography>
        )}
      </DialogContent>
      <DialogActions>
        <Button 
          color="primary" 
          variant="contained"
          href={filePreview?.url}
          target="_blank"
          download
        >
          Download File
        </Button>
        <Button onClick={() => setFilePreview(null)} color="secondary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );

  const renderAttachmentIcon = (fileType) => {
    if (fileType === 'application/pdf') return <PictureAsPdf />;
    if (fileType.startsWith('image/')) return <Image />;
    return <Description />;
  };

  const renderRequestDetailsModal = () => (
    <Dialog 
      open={openModal} 
      onClose={() => setOpenModal(false)}
      maxWidth="md"
      fullWidth
    >
      {selectedRequest && (
        <>
          <DialogTitle>
            Student Request: {selectedRequest.studentName}
            <Typography variant="subtitle2">
              <Person sx={{ verticalAlign: 'middle', mr: 1 }} />
              {selectedRequest.semester}
            </Typography>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="h6">Student Information</Typography>
                <Box>
                  <Typography>Name: {selectedRequest.studentName}</Typography>
                  <Typography>Student ID: {selectedRequest.studentId}</Typography>
                  <Typography>Department: {selectedRequest.department}</Typography>
                  <Typography>Semester: {selectedRequest.semester}</Typography>
                </Box>
              </Grid>
              {/* <Grid item xs={12} md={6}>
                <Typography variant="h6">Academic Performance</Typography>
                <Box>
                  <Typography>CGPA: {selectedRequest.academicPerformance.cgpa}</Typography>
                  <Typography>Attendance: {selectedRequest.academicPerformance.attendancePercentage}</Typography>
                  <Typography>Backlogs: {selectedRequest.academicPerformance.backlogCount}</Typography>
                </Box>
              </Grid> */}
              <Grid item xs={12} md={6}>
                <Typography variant="h6">Request Details</Typography>
                <Box>
                  {selectedRequest.requestType === 'Leave' && (
                    <>
                      <Typography>Reason: {selectedRequest.reason}</Typography>
                      <Typography>Start Date: {selectedRequest.startDate}</Typography>
                      <Typography>End Date: {selectedRequest.endDate}</Typography>
                    </>
                  )}
                  {selectedRequest.requestType === 'Internship' && (
                    <>
                      <Typography>Company: {selectedRequest.companyName}</Typography>
                      <Typography>Duration: {selectedRequest.duration}</Typography>
                    </>
                  )}
                  {selectedRequest.requestType === 'On Duty' && (
                    <>
                      <Typography>Reason: {selectedRequest.reason}</Typography>
                      <Typography>Start Date: {selectedRequest.startDate}</Typography>
                      <Typography>End Date: {selectedRequest.endDate}</Typography>
                    </>
                  )}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6">Workflow Status</Typography>
                <Box>
                  {selectedRequest.workflow.map((step, index) => (
                    <Grid container key={index} spacing={2} sx={{ mb: 1 }}>
                      <Grid item xs={4}>
                        <Typography>{step.stage}</Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Chip 
                          label={step.status} 
                          color={
                            step.status === 'Completed' ? 'success' : 
                            step.status === 'Pending' ? 'warning' : 
                            step.status === 'Awaiting' ? 'default' : 'error'
                          }
                          size="small"
                        />
                      </Grid>
                      <Grid item xs={4}>
                        <Typography variant="body2">
                          {step.approvedBy ? `By ${step.approvedBy}` : 'Awaiting Approval'}
                        </Typography>
                      </Grid>
                    </Grid>
                  ))}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="h6">Attachments</Typography>
                <Box display="flex" gap={2}>
                  {selectedRequest.attachments.map(attachment => (
                    <Button 
                      key={attachment.name} 
                      variant="outlined" 
                      startIcon={renderAttachmentIcon(attachment.type)}
                      onClick={() => handleFilePreview(attachment)}
                    >
                      {attachment.name}
                    </Button>
                  ))}
                </Box>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button 
              color="primary" 
              startIcon={<Check />}
              onClick={() => handleRequestAction(selectedRequest.id, 'Completed')}
              disabled={
                selectedRequest.workflow.find(
                  step => step.stage === 'Class Advisor' && step.status === 'Pending'
                ) ? false : true
              }
            >
              Recommend
            </Button>
            <Button 
              color="error" 
              startIcon={<Close />}
              onClick={() => handleRequestAction(selectedRequest.id, 'Rejected')}
              disabled={
                selectedRequest.workflow.find(
                  step => step.stage === 'Class Advisor' && step.status === 'Pending'
                ) ? false : true
              }
            >
              Not Recommended
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );

  // Filter requests
  const filteredRequests = requests.filter(request => 
    requestFilter === 'All' || request.requestType === requestFilter
  );

  return (
    <Box sx={{ p: 4, minHeight: '100vh' }}>
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          Class Advisor Request Management
        </Typography>

        {/* Request Type Filter Dropdown */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
          <FormControl variant="outlined" sx={{ minWidth: 200 }}>
            <InputLabel>Filter Requests</InputLabel>
            <Select
              value={requestFilter}
              onChange={(e) => setRequestFilter(e.target.value)}
              label="Filter Requests"
            >
              <MenuItem value="All">All Requests</MenuItem>
              <MenuItem value="Leave">Leave Requests</MenuItem>
              <MenuItem value="On Duty">On Duty Requests</MenuItem>
              <MenuItem value="Internship">Internship Requests</MenuItem>
            </Select>
          </FormControl>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Student Name</TableCell>
                <TableCell>Department</TableCell>
                <TableCell>Semester</TableCell>
                <TableCell>Request Type</TableCell>
                {/* <TableCell>Academic Performance</TableCell> */}
                <TableCell>Current Stage</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredRequests.map(request => {
                const currentStage = request.workflow.find(step => step.stage === 'Class Advisor' && step.status === 'Pending');
                return (
                  <TableRow key={request.id}>
                    <TableCell>{request.studentName}</TableCell>
                    <TableCell>{request.department}</TableCell>
                    <TableCell>{request.semester}</TableCell>
                    <TableCell>{request.requestType}</TableCell>
                    {/* <TableCell>
                      <Tooltip 
                        title={`CGPA: ${request.academicPerformance.cgpa}, Attendance: ${request.academicPerformance.attendancePercentage}`}
                      >
                        <Chip 
                          label={`CGPA: ${request.academicPerformance.cgpa}`} 
                          color={
                            request.academicPerformance.cgpa >= '9.0' ? 'success' : 
                            request.academicPerformance.cgpa >= '8.0' ? 'primary' : 'warning'
                          }
                          size="small"
                        />
                      </Tooltip>
                    </TableCell> */}
                    <TableCell>
                      <Chip 
                        label={currentStage ? 'Pending' : 'Processed'} 
                        color={currentStage ? 'warning' : 'success'}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>
                      <Tooltip title="View Student Request">
                        <IconButton 
                          color="primary"
                          onClick={() => {
                            setSelectedRequest(request);
                            setOpenModal(true);
                          }}
                        >
                          <Visibility />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Notification Snackbar */}
      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseNotification} 
          severity={notification.severity} 
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>

      {renderRequestDetailsModal()}
      {renderFilePreviewModal()}
    </Box>
  );
};

export default ClassAdvisorRequestManagement;