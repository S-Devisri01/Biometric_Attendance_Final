import React, { useState } from "react";
import {
  Paper,
  Typography,
  Box,
  Grid,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Chip
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import PendingIcon from "@mui/icons-material/Pending";
import CancelIcon from "@mui/icons-material/Cancel";
import QueryBuilder from "@mui/icons-material/QueryBuilder";
import { useNavigate } from "react-router-dom";

const LeaveApprovalStatus = () => {
  const navigate = useNavigate();
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);

  const requests = [
    {
      id: 1,
      type: "Casual Leave",
      date: "2024-10-01",
      stages: [
        { stage: "Principal", status: "Approved" },
      ],
    },
    {
      id: 2,
      type: "Sick Leave",
      date: "2024-10-02",
      stages: [
        { stage: "Principal", status: "Pending" },
      ],
    },
    {
      id: 4,
      type: "On-Duty",
      date: "2024-10-07",
      stages: [
        { stage: "Principal", status: "Pending" },
      ],
    }
  ];

  const getStatusDetails = (status) => {
    switch (status) {
      case "Approved":
        return { 
          icon: <CheckCircleIcon sx={{ color: '#2e7d32' }} />, 
          color: '#4caf50', 
          bgColor: '#e8f5e9' 
        };
      case "Pending":
        return { 
          icon: <PendingIcon sx={{ color: '#ed6c02' }} />, 
          color: '#ff9800', 
          bgColor: '#fff3e0' 
        };
      case "Rejected":
        return { 
          icon: <CancelIcon sx={{ color: '#d32f2f' }} />, 
          color: '#f44336', 
          bgColor: '#ffebee' 
        };
      default:
        return { 
          icon: <QueryBuilder sx={{ color: '#757575' }} />, 
          color: '#9e9e9e', 
          bgColor: '#fafafa' 
        };
    }
  };

  const handleRequestDetails = (request) => {
    setSelectedRequest(request);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedRequest(null);
  };

  return (
    <Box 
      sx={{ 
        flexGrow: 1, 
        p: 3, 
        
        minHeight: '100vh'
      }}
    >
      <Paper
        elevation={6}
        sx={{
          p: 4,
          backgroundColor: 'white',
          borderRadius: 3,
          boxShadow: '0 10px 25px rgba(0,0,0,0.1)'
        }}
      >
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            mb: 4, 
            textAlign: 'center', 
            fontWeight: 700,
            color: '#2c3e50',
            letterSpacing: 1
          }}
        >
          Leave Request Dashboard
        </Typography>

        <Grid container spacing={3}>
          {requests.map((request) => {
            const statusDetails = getStatusDetails(request.stages[0].status);
            return (
              <Grid item xs={12} key={request.id}>
                <Paper 
                  elevation={4}
                  sx={{
                    p: 2,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    backgroundColor: statusDetails.bgColor,
                    border: `1px solid ${statusDetails.color}`,
                    borderRadius: 2,
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: '0 6px 15px rgba(0,0,0,0.15)'
                    }
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {statusDetails.icon}
                    <Box sx={{ ml: 2 }}>
                      <Typography 
                        variant="subtitle1" 
                        sx={{ 
                          fontWeight: 600, 
                          color: '#34495e' 
                        }}
                      >
                        {request.type}
                      </Typography>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          color: '#7f8c8d',
                          mt: 0.5 
                        }}
                      >
                        Date: {request.date}
                      </Typography>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Chip
                      label={request.stages[0].status}
                      color="primary"
                      variant="outlined"
                      sx={{
                        fontWeight: 600,
                        backgroundColor: statusDetails.color,
                        color: 'white',
                        mr: 2
                      }}
                    />
                    <Button 
                      variant="contained"
                      size="small"
                      sx={{
                        backgroundColor: '#3498db',
                        '&:hover': {
                          backgroundColor: '#2980b9'
                        }
                      }}
                      onClick={() => handleRequestDetails(request)}
                    >
                      Details
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            );
          })}
        </Grid>
      </Paper>

      {/* Request Details Dialog */}
      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        maxWidth="xs"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            p: 1
          }
        }}
      >
        <DialogTitle sx={{ textAlign: 'center', color: '#2c3e50' }}>
          Request Details
        </DialogTitle>
        <DialogContent>
          {selectedRequest && (
            <Box>
              <Typography 
                variant="body1" 
                sx={{ mb: 1, display: 'flex', justifyContent: 'space-between' }}
              >
                <span style={{ fontWeight: 600 }}>Type:</span> 
                {selectedRequest.type}
              </Typography>
              <Typography 
                variant="body1" 
                sx={{ mb: 1, display: 'flex', justifyContent: 'space-between' }}
              >
                <span style={{ fontWeight: 600 }}>Date:</span> 
                {selectedRequest.date}
              </Typography>
              <Typography 
                variant="body1" 
                sx={{ display: 'flex', justifyContent: 'space-between' }}
              >
                <span style={{ fontWeight: 600 }}>Status:</span> 
                {selectedRequest.stages[0].status}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={handleCloseDialog} 
            variant="contained" 
            color="primary"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default LeaveApprovalStatus;