import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { 
  Grid, 
  Paper, 
  Typography, 
  Divider, 
  Box, 
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  FormControl,
  Select,
  MenuItem,
  Button,
  Dialog,
  DialogTitle,
  DialogContent
} from '@mui/material';
import { 
  School as SchoolIcon,
  Warning as WarningIcon,
  PersonSearch as PersonSearchIcon
} from '@mui/icons-material';

const ClassAdvisorAttendanceDashboard = () => {
  // State management
  const [selectedDepartment, setSelectedDepartment] = useState('CSE');
  const [selectedSemester, setSelectedSemester] = useState('Semester 4');
  const [openStudentDialog, setOpenStudentDialog] = useState(false);
  const [selectedStudentDetails, setSelectedStudentDetails] = useState(null);

  // Comprehensive Class Data
  const classAttendanceData = {
    'CSE': {
      'Semester 4': {
        totalStudents: 60,
        attendanceData: [
          { name: 'Jan', averageAttendance: 85.5, presentCount: 52 },
          { name: 'Feb', averageAttendance: 87.2, presentCount: 54 },
          { name: 'Mar', averageAttendance: 88.1, presentCount: 55 }
        ],
        students: [
          { 
            name: 'Aarav Patel', 
            rollNo: 'CSE2024-042', 
            totalClasses: 90, 
            classesAttended: 75, 
            attendancePercentage: 83.3,
            subjects: [
              { name: 'Data Structures', attendance: 85 },
              { name: 'Computer Networks', attendance: 80 },
              { name: 'Operating Systems', attendance: 82 }
            ]
          },
          { 
            name: 'Priya Sharma', 
            rollNo: 'CSE2024-053', 
            totalClasses: 90, 
            classesAttended: 80, 
            attendancePercentage: 88.9,
            subjects: [
              { name: 'Data Structures', attendance: 90 },
              { name: 'Computer Networks', attendance: 88 },
              { name: 'Operating Systems', attendance: 87 }
            ]
          },
          // More students...
          { 
            name: 'Rohit Kumar', 
            rollNo: 'CSE2024-031', 
            totalClasses: 90, 
            classesAttended: 65, 
            attendancePercentage: 72.2,
            subjects: [
              { name: 'Data Structures', attendance: 70 },
              { name: 'Computer Networks', attendance: 75 },
              { name: 'Operating Systems', attendance: 71 }
            ]
          }
        ]
      },
      'Semester 6': {
        totalStudents: 55,
        attendanceData: [
          { name: 'Jan', averageAttendance: 86.5, presentCount: 48 },
          { name: 'Feb', averageAttendance: 87.8, presentCount: 50 },
          { name: 'Mar', averageAttendance: 89.1, presentCount: 51 }
        ],
        students: [
          // Similar structure to Semester 4
        ]
      }
    },
    'ECE': {
      'Semester 4': {
        totalStudents: 55,
        attendanceData: [
          { name: 'Jan', averageAttendance: 84.5, presentCount: 47 },
          { name: 'Feb', averageAttendance: 86.2, presentCount: 49 },
          { name: 'Mar', averageAttendance: 87.1, presentCount: 50 }
        ],
        students: [
          // Similar structure to CSE
        ]
      }
    }
  };

  // Open student details dialog
  const handleOpenStudentDetails = (student) => {
    setSelectedStudentDetails(student);
    setOpenStudentDialog(true);
  };

  // Render Class Overview
  const renderClassOverview = () => {
    const classData = classAttendanceData[selectedDepartment][selectedSemester];
    const latestMonthData = classData.attendanceData[classData.attendanceData.length - 1];

    return (
      <Paper 
        sx={{ 
          p: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #6a11cb 0%, #2575fc 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          {selectedDepartment} - {selectedSemester} Attendance Overview
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Box textAlign="center">
              <SchoolIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Total Students</Typography>
              <Typography variant="h4">{classData.totalStudents}</Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <PersonSearchIcon sx={{ fontSize: 50, mb: 1 }} />
              <Typography variant="h6">Present Students</Typography>
              <Typography variant="h4">{latestMonthData.presentCount}</Typography>
            </Box>
          </Grid>
          <Grid item xs={4}>
            <Box textAlign="center">
              <WarningIcon sx={{ fontSize: 50, mb: 1, color: 'yellow' }} />
              <Typography variant="h6">Low Attendance</Typography>
              <Typography variant="h4">
                {classData.students.filter(student => student.attendancePercentage < 75).length}
              </Typography>
            </Box>
          </Grid>
        </Grid>
        <Divider sx={{ my: 2, bgcolor: 'white' }} />
        <Typography variant="h6" sx={{ textAlign: 'center' }}>
          Latest Month Attendance: {latestMonthData.averageAttendance.toFixed(1)}%
        </Typography>
      </Paper>
    );
  };

  // Render Attendance Trend
  const renderAttendanceTrend = () => {
    const classData = classAttendanceData[selectedDepartment][selectedSemester];
    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(135deg, rgba(54, 162, 235, 0.8) 0%, rgba(255, 99, 132, 0.8) 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Monthly Attendance Trend
        </Typography>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={classData.attendanceData}>
            <XAxis dataKey="name" stroke="white" />
            <YAxis stroke="white" domain={[80, 90]} />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="averageAttendance" 
              stroke="#fff" 
              strokeWidth={3}
              name="Average Attendance"
            />
          </LineChart>
        </ResponsiveContainer>
      </Paper>
    );
  };

  // Render Student Attendance Table
  const renderStudentAttendanceTable = () => {
    const classData = classAttendanceData[selectedDepartment][selectedSemester];
    const lowAttendanceStudents = classData.students.filter(student => student.attendancePercentage < 75);

    return (
      <Paper 
        sx={{ 
          p: 3, 
          mt: 3, 
          borderRadius: 2, 
          background: 'linear-gradient(to right, #ff416c 0%, #ff4b2b 100%)',
          color: 'white'
        }}
      >
        <Typography variant="h5" sx={{ mb: 3, textAlign: 'center' }}>
          Student Attendance Details
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ color: 'white' }}>Name</TableCell>
                <TableCell sx={{ color: 'white' }}>Roll No</TableCell>
                <TableCell sx={{ color: 'white' }}>Total Classes</TableCell>
                <TableCell sx={{ color: 'white' }}>Attended</TableCell>
                <TableCell sx={{ color: 'white' }}>Attendance %</TableCell>
                <TableCell sx={{ color: 'white' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {classData.students.map((student, index) => (
                <TableRow key={index}>
                  <TableCell sx={{ color: 'white' }}>{student.name}</TableCell>
                  <TableCell sx={{ color: 'white' }}>{student.rollNo}</TableCell>
                  <TableCell sx={{ color: 'white' }}>{student.totalClasses}</TableCell>
                  <TableCell sx={{ color: 'white' }}>{student.classesAttended}</TableCell>
                  <TableCell sx={{ 
                    color: student.attendancePercentage < 75 ? 'yellow' : 'white',
                    fontWeight: 'bold'
                  }}>
                    {student.attendancePercentage.toFixed(1)}%
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="contained" 
                      color="info" 
                      size="small"
                      onClick={() => handleOpenStudentDetails(student)}
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    );
  };

  // Student Details Dialog
  const renderStudentDetailsDialog = () => {
    return (
      <Dialog 
        open={openStudentDialog} 
        onClose={() => setOpenStudentDialog(false)}
        maxWidth="md"
        fullWidth
      >
        {selectedStudentDetails && (
          <>
            <DialogTitle>
              {selectedStudentDetails.name} - Detailed Attendance
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="h6">Personal Details</Typography>
                  <Typography>Roll No: {selectedStudentDetails.rollNo}</Typography>
                  <Typography>Total Classes: {selectedStudentDetails.totalClasses}</Typography>
                  <Typography>Classes Attended: {selectedStudentDetails.classesAttended}</Typography>
                  <Typography>Attendance Percentage: {selectedStudentDetails.attendancePercentage.toFixed(1)}%</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="h6">Subject-wise Attendance</Typography>
                  {selectedStudentDetails.subjects.map((subject, index) => (
                    <Typography key={index}>
                      {subject.name}: {subject.attendance}%
                    </Typography>
                  ))}
                </Grid>
              </Grid>
            </DialogContent>
          </>
        )}
      </Dialog>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <div className="flex-1 p-8 overflow-y-auto">
        <Typography 
          variant="h4" 
          gutterBottom 
          sx={{ 
            textAlign: 'center', 
            fontWeight: 'bold', 
            color: '#2c3e50', 
            mb: 4 
          }}
        >
          Class Advisor Attendance Dashboard
        </Typography>

        {/* Department and Semester Selectors */}
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={6}>
            <FormControl fullWidth>
              <Select
                value={selectedDepartment}
                onChange={(e) => setSelectedDepartment(e.target.value)}
                sx={{ bgcolor: 'white' }}
              >
                {Object.keys(classAttendanceData).map((dept) => (
                  <MenuItem key={dept} value={dept}>{dept}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <FormControl fullWidth>
              <Select
                value={selectedSemester}
                onChange={(e) => setSelectedSemester(e.target.value)}
                sx={{ bgcolor: 'white' }}
              >
                {Object.keys(classAttendanceData[selectedDepartment]).map((semester) => (
                  <MenuItem key={semester} value={semester}>{semester}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Class Overview */}
        {renderClassOverview()}

        {/* Attendance Trend */}
        {renderAttendanceTrend()}

        {/* Student Attendance Table */}
        {renderStudentAttendanceTable()}

        {/* Student Details Dialog */}
        {renderStudentDetailsDialog()}
      </div>
    </div>
  );
};

export default ClassAdvisorAttendanceDashboard;