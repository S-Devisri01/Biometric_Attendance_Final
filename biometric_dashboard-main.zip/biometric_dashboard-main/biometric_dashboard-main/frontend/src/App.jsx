import { MainNavigator } from "./Navigation/MainNavigator";

function App() {
  return (
      <MainNavigator />
  );
}

export default App;

