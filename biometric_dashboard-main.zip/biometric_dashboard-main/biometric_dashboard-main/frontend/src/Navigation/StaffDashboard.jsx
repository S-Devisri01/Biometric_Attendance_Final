import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Collapse,
  Menu,
  MenuItem,
  Grid,
  Paper,
  Avatar,
  Box,
  Divider,
  useTheme,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
  Card,
  CardContent,
} from "@mui/material";
import { 
  ExpandLess, 
  ExpandMore, 
  Person as PersonIcon, 
  Logout as LogoutIcon,
  Dashboard as DashboardIcon,
  EventNote as EventNoteIcon,
  RequestQuote as RequestQuoteIcon,
  Assignment as AssignmentIcon,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

import StaffLeaveApplication from "../components/Staff/StaffLeaveApplication"
import RequestTable from "../components/Staff/RequestTable";
import StudentAttendance from "../components/Staff/StudentAttendance";
import LeaveApprovalStatus from "../components/Staff/StaffLeaveApprovalStatus";
import PersonalAttendance from "../components/Staff/PersonalAttendance";

const userProfile = {
  name: "Jaseenash",
  role: "Class Advisor",
  department: "Computer Science",
  businessHours: "9 am - 4 pm",
  currentDate: new Date().toLocaleDateString(),
};

const leaves = { atWork: 10, leaveTaken: 33, leaveBalance: 24 };
const utilization = { percentage: "98%", totalWorkingDays: 23, organizationWorkingDays: 23 };

const Dashboard = () => {
  const theme = useTheme();
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false);
  const { logout } = useAuth();
  const [attendanceOpen, setAttendanceOpen] = useState(false);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);
  const [selectedContent, setSelectedContent] = useState("dashboard");
  const navigate = useNavigate();

  const handleProfileMenuOpen = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };
  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };
  const handleToggleAttendance = () => {
    setAttendanceOpen((prev) => !prev);
  };
  const handleLogoutClick = () => {
    setLogoutDialogOpen(true);
  };
  const handleLogoutConfirm = () => {
    logout();
    navigate("/logout");
  };
  const handleLogoutCancel = () => {
    setLogoutDialogOpen(false);
  };

  const sidebarMenuItems = [
    { 
      icon: <DashboardIcon />, 
      text: "Dashboard", 
      onClick: () => setSelectedContent("dashboard") 
    },
    { 
      icon: <EventNoteIcon />, 
      text: "Attendance View", 
      subItems: [
        { 
          text: "Student Attendance", 
          onClick: () => setSelectedContent("studentAttendance") 
        },
        { 
          text: "Personal Attendance", 
          onClick: () => setSelectedContent("personalAttendance") 
        }
      ]
    },
    { 
      icon: <RequestQuoteIcon />, 
      text: "Request Table", 
      onClick: () => setSelectedContent("requestTable") 
    },
    { 
      icon: <AssignmentIcon />, 
      text: "Staff Leave Request", 
      onClick: () => setSelectedContent("staffleaveRequest") 
    },
    { 
      icon: <AssignmentIcon />, 
      text: "Staff Leave Approval Status", 
      onClick: () => setSelectedContent("staffleaveApprovalStatus") 
    }
  ];

  return (
    <>
      <Box sx={{ 
        display: "flex", 
        background: "linear-gradient(135deg, #f5f7fa 0%, rgb(111, 228, 207) 100%)", 
        minHeight: "100vh" 
      }}>
        <AppBar 
          position="fixed" 
          sx={{ 
            zIndex: theme.zIndex.drawer + 1, 
            background: "linear-gradient(to right, rgb(111, 228, 207) 0%, rgb(111, 228, 207) 100%)",
            boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
          }}
        >
          <Toolbar>
            <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: "bold", letterSpacing: 1 }}>
              Staff Dashboard
            </Typography>
            <IconButton onClick={handleProfileMenuOpen} color="inherit">
              <PersonIcon />
            </IconButton>
            <Menu anchorEl={profileAnchorEl} open={Boolean(profileAnchorEl)} onClose={handleProfileMenuClose}>
              <MenuItem onClick={() => { setSelectedContent("profile"); handleProfileMenuClose(); }}>Profile</MenuItem>
              <MenuItem onClick={handleLogoutClick}>Logout</MenuItem>
            </Menu>
          </Toolbar>
        </AppBar>

        <Drawer
          variant="permanent"
          sx={{
            width: 280,
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: 280,
              boxSizing: "border-box",
              background: "linear-gradient(to bottom, #ffffff 0%, #e6e9f0 100%)",
              borderRight: "1px solid rgba(0,0,0,0.1)",
              boxShadow: "2px 0 5px rgba(0,0,0,0.05)"
            },
          }}
        >
          <Toolbar />
          <Box sx={{ overflow: "auto" }}>
            <List>
              {sidebarMenuItems.map((item, index) => (
                <React.Fragment key={index}>
                  {item.subItems ? (
                    <>
                      <ListItem 
                        button 
                        onClick={handleToggleAttendance}
                        sx={{ 
                          '&:hover': { 
                            backgroundColor: 'rgba(0,0,0,0.05)', 
                            borderRadius: 2 
                          } 
                        }}
                      >
                        {item.icon}
                        <ListItemText 
                          primary={item.text} 
                          sx={{ ml: 2, fontWeight: 'medium' }} 
                        />
                        {attendanceOpen ? <ExpandLess /> : <ExpandMore />}
                      </ListItem>
                      <Collapse in={attendanceOpen} timeout="auto" unmountOnExit>
                        <List component="div" disablePadding>
                          {item.subItems.map((subItem, subIndex) => (
                            <ListItem 
                              key={subIndex} 
                              button 
                              sx={{ 
                                pl: 4, 
                                '&:hover': { 
                                  backgroundColor: 'rgba(0,0,0,0.05)', 
                                  borderRadius: 2 
                                } 
                              }} 
                              onClick={subItem.onClick}
                            >
                              <ListItemText primary={subItem.text} />
                            </ListItem>
                          ))}
                        </List>
                      </Collapse>
                    </>
                  ) : (
                    <ListItem 
                      button 
                      onClick={item.onClick}
                      sx={{ 
                        '&:hover': { 
                          backgroundColor: 'rgba(0,0,0,0.05)', 
                          borderRadius: 2 
                        } 
                      }}
                    >
                      {item.icon}
                      <ListItemText 
                        primary={item.text} 
                        sx={{ ml: 2, fontWeight: 'medium' }} 
                      />
                    </ListItem>
                  )}
                </React.Fragment>
              ))}
            </List>
            <Divider sx={{ my: 2 }} />
            <List sx={{ mt: "auto" }}>
              <ListItem 
                button 
                onClick={handleLogoutClick}
                sx={{ 
                  '&:hover': { 
                    backgroundColor: 'rgba(0,0,0,0.05)', 
                    borderRadius: 2 
                  } 
                }}
              >
                <LogoutIcon sx={{ mr: 2 }} />
                <ListItemText primary="Logout" />
              </ListItem>
            </List>
          </Box>
        </Drawer>

        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Toolbar />
          
          {selectedContent === "dashboard" && (
            <>
              <Typography 
                variant="h4" 
                gutterBottom 
                sx={{ 
                  fontWeight: "bold", 
                  mb: 3, 
                  color: "#2575fc", 
                  textShadow: "1px 1px 2px rgba(0,0,0,0.1)" 
                }}
              >
                Welcome to the Staff Dashboard
              </Typography>
              <Grid container spacing={3}>
                {/* Profile Section */}
                <Grid item xs={12} md={6}>
                  <Card 
                    elevation={6} 
                    sx={{ 
                      borderRadius: 3, 
                      background: "linear-gradient(145deg, #f0f5fc 0%, #e6e9f0 100%)",
                      transition: "transform 0.3s ease-in-out",
                      '&:hover': { transform: 'scale(1.02)' }
                    }}
                  >
                    <CardContent>
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Avatar 
                          sx={{ 
                            width: 80, 
                            height: 80, 
                            backgroundColor: "#2575fc", 
                            mr: 3,
                            boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
                          }}
                        >
                          {userProfile.name.charAt(0)}
                        </Avatar>
                        <Box>
                          <Typography variant="h6" sx={{ fontWeight: "bold", color: "#2575fc" }}>
                            {userProfile.name}
                          </Typography>
                          <Typography variant="body1" color="textSecondary">
                            {userProfile.role}
                          </Typography>
                          <Typography variant="body2" color="textSecondary">
                            {userProfile.department}
                          </Typography>
                          <Divider sx={{ my: 1 }} />
                          <Typography variant="caption" color="textSecondary">
                            Business Hours: {userProfile.businessHours}
                          </Typography>
                          <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
                            {userProfile.currentDate}
                          </Typography>
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>

                {/* Leave Information */}
                <Grid item xs={12} md={6}>
                  <Card 
                    elevation={6} 
                    sx={{ 
                      borderRadius: 3, 
                      background: "linear-gradient(145deg, #f0f5fc 0%, #e6e9f0 100%)",
                      transition: "transform 0.3s ease-in-out",
                      '&:hover': { transform: 'scale(1.02)' }
                    }}
                  >
                    <CardContent>
                      <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: "#2575fc" }}>
                        Leave Information
                      </Typography>
                      <Divider sx={{ mb: 2.5 }} />
                      <Grid container spacing={2}>
                        {Object.entries(leaves).map(([key, value]) => (
                          <Grid item xs={4} key={key}>
                            <Box 
                              textAlign="center" 
                              sx={{ 
                                p: 1, 
                                borderRadius: 2, 
                                background: "rgba(37, 117, 252, 0.05)",
                                transition: "transform 0.2s ease-in-out",
                                '&:hover': { transform: 'scale(1.05)' }
                              }}
                            >
                              <Typography variant="body1" color="textSecondary" sx={{ textTransform: 'capitalize' }}>
                                {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                              </Typography>
                              <Typography variant="h6" sx={{ fontWeight: "bold", color: "#2575fc" }}>
                                {value}
                              </Typography>
                            </Box>
                          </Grid>
                        ))}
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>

                {/* Utilization Information */}
                <Grid item xs={12} md={12}>
                  <Card 
                    elevation={6} 
                    sx={{ 
                      borderRadius: 3, 
                      background: "linear-gradient(145deg, #f0f5fc 0%, #e6e9f0 100%)",
                      transition: "transform 0.3s ease-in-out",
                      '&:hover': { transform: 'scale(1.02)' }
                    }}
                  >
                    <CardContent>
                      <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: "#2575fc" }}>
                        Utilization
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      <Box sx={{ textAlign: "center" }}>
                        <Box
                          sx={{
                            width: 120,
                            height: 120,
                            borderRadius: "50%",
                            border: `6px solid #2575fc`,
                            mx: "auto",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            background: "linear-gradient(145deg, #ffffff 0%, #e6e9f0 100%)",
                            boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
                          }}
                        >
                          <Typography variant="h4" sx={{ fontWeight: "bold", color: "#2575fc" }}>
                            {utilization.percentage}
                          </Typography>
                        </Box>
                        <Typography variant="body1" sx={{ mt: 2, color: "text.secondary" }}>
                          Total Working Days: {utilization.totalWorkingDays}
                        </Typography>
                        <Typography variant="body1" color="text.secondary">
                          Organization Working Days: {utilization.organizationWorkingDays}
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </>
          )}
          
          {selectedContent === "studentAttendance" && <StudentAttendance />}
          {selectedContent === "personalAttendance" && <PersonalAttendance />}
          {selectedContent === "requestTable" && <RequestTable />}
          {selectedContent === "staffleaveRequest" && <StaffLeaveApplication />}
          {selectedContent === "staffleaveApprovalStatus" && <LeaveApprovalStatus />}
        </Box>
      </Box>

      <Dialog open={logoutDialogOpen} onClose={handleLogoutCancel}>
        <DialogTitle sx={{ fontWeight: 'bold', color: '#2575fc' }}>Confirm Logout</DialogTitle>
        <DialogContent>
          <DialogContentText>Are you sure you want to logout?</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={handleLogoutCancel} 
            color="primary" 
            variant="outlined"
            sx={{ mr: 1 }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleLogoutConfirm} 
            color="primary" 
            variant="contained"
          >
            Logout
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default Dashboard;