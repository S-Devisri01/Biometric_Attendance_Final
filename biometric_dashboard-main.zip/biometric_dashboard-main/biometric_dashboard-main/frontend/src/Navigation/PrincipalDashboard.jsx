import React, { useState } from "react";
import {
  Box,
  Typography,
  Grid,
  Avatar,
  Card,
  CardContent,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Collapse,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  Toolbar,
  AppBar,
  Divider
} from "@mui/material";
import { 
  Dashboard as DashboardIcon,
  Person as PersonIcon,
  EventNote as EventNoteIcon,
  RequestQuote as RequestQuoteIcon,
  Logout as LogoutIcon,
  ExpandLess, 
  ExpandMore 
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Import existing components
import RequestTable from "../components/Principal/RequestTable";
import StudentAttendance from "../components/Principal/StudentAttendance";
import PersonalAttendance from "../components/Principal/PersonalAttendance";

const userProfile = {
  name: "Dr. Rajesh Kumar",
  role: "Principal",
  department: "Educational Administration",
  businessHours: "9 am - 5 pm",
  currentDate: new Date().toLocaleDateString(),
};

const leaves = { 
  atWork: 15, 
  leaveTaken: 25, 
  leaveBalance: 20 
};

const utilization = { 
  percentage: "96%", 
  totalWorkingDays: 25, 
  organizationWorkingDays: 25 
};

const Dashboard = () => {
  const [selectedContent, setSelectedContent] = useState("dashboard");
  const [anchorEl, setAnchorEl] = useState(null);
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false);
  const [attendanceOpen, setAttendanceOpen] = useState(false);
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogoutClick = () => {
    setLogoutDialogOpen(true);
    handleProfileMenuClose();
  };

  const handleLogoutConfirm = () => {
    logout();
    navigate("/logout");
  };

  const handleToggleAttendance = () => {
    setAttendanceOpen((prev) => !prev);
  };

  const sidebarMenuItems = [
    { 
      icon: <DashboardIcon />, 
      text: "Dashboard", 
      onClick: () => setSelectedContent("dashboard") 
    },
    { 
      icon: <EventNoteIcon />, 
      text: "Attendance View", 
      subItems: [
        { 
          text: "Student Attendance", 
          onClick: () => setSelectedContent("studentAttendance") 
        },
        { 
          text: "Personal Attendance", 
          onClick: () => setSelectedContent("personalAttendance") 
        }
      ]
    },
    { 
      icon: <RequestQuoteIcon />, 
      text: "Request Table", 
      onClick: () => setSelectedContent("requestTable") 
    }
  ];

  const renderDashboardContent = () => (
    <Box sx={{ p: 3 }}>
      <Typography 
        variant="h4" 
        gutterBottom 
        sx={{ 
          fontWeight: "bold", 
          mb: 3, 
          color: "#1976d2", 
          textShadow: "1px 1px 2px rgba(0,0,0,0.1)" 
        }}
      >
        Welcome to the Principal Dashboard
      </Typography>
      <Grid container spacing={3}>
        {/* Profile Section */}
        <Grid item xs={12} md={6}>
          <Card 
            elevation={6} 
            sx={{ 
              borderRadius: 3, 
              background: "linear-gradient(145deg, #f0f5fc 0%, rgb(110, 216, 232) 100%)",
              transition: "transform 0.3s ease-in-out",
              '&:hover': { transform: 'scale(1.02)' }
            }}
          >
            <CardContent>
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <Avatar 
                  sx={{ 
                    width: 80, 
                    height: 80, 
                    backgroundColor: "#1976d2", 
                    mr: 3,
                    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
                  }}
                >
                  {userProfile.name.charAt(0)}
                </Avatar>
                <Box>
                  <Typography variant="h6" sx={{ fontWeight: "bold", color: "#1976d2" }}>
                    {userProfile.name}
                  </Typography>
                  <Typography variant="body1" color="textSecondary">
                    {userProfile.role}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    {userProfile.department}
                  </Typography>
                  <Divider sx={{ my: 1 }} />
                  <Typography variant="caption" color="textSecondary">
                    Business Hours: {userProfile.businessHours}
                  </Typography>
                  <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
                    {userProfile.currentDate}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Leave Information */}
        <Grid item xs={12} md={6}>
          <Card 
            elevation={6} 
            sx={{ 
              borderRadius: 3, 
              background: "linear-gradient(145deg, #f0f5fc 0%, rgb(110, 216, 232) 100%)",
              transition: "transform 0.3s ease-in-out",
              '&:hover': { transform: 'scale(1.02)' }
            }}
          >
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: "#1976d2" }}>
                Leave Information
              </Typography>
              <Divider sx={{ mb: 2.5 }} />
              <Grid container spacing={2}>
                {Object.entries(leaves).map(([key, value]) => (
                  <Grid item xs={4} key={key}>
                    <Box 
                      textAlign="center" 
                      sx={{ 
                        p: 1, 
                        borderRadius: 2, 
                        background: "rgba(25, 118, 210, 0.05)",
                        transition: "transform 0.2s ease-in-out",
                        '&:hover': { transform: 'scale(1.05)' }
                      }}
                    >
                      <Typography variant="body1" color="textSecondary" sx={{ textTransform: 'capitalize' }}>
                        {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: "bold", color: "#1976d2" }}>
                        {value}
                      </Typography>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>
        </Grid>

        {/* Utilization Information */}
        <Grid item xs={12} md={12}>
          <Card 
            elevation={6} 
            sx={{ 
              borderRadius: 3, 
              background: "linear-gradient(145deg, #f0f5fc 0%, rgb(110, 216, 232) 100%)",
              transition: "transform 0.3s ease-in-out",
              '&:hover': { transform: 'scale(1.02)' }
            }}
          >
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: "#1976d2" }}>
                Utilization
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ textAlign: "center" }}>
                <Box
                  sx={{
                    width: 120,
                    height: 120,
                    borderRadius: "50%",
                    border: `6px solid #1976d2`,
                    mx: "auto",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "linear-gradient(145deg, #ffffff 0%, #e6e9f0 100%)",
                    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
                  }}
                >
                  <Typography variant="h4" sx={{ fontWeight: "bold", color: "#1976d2" }}>
                    {utilization.percentage}
                  </Typography>
                </Box>
                <Typography variant="body1" sx={{ mt: 2, color: "text.secondary" }}>
                  Total Working Days: {utilization.totalWorkingDays}
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Organization Working Days: {utilization.organizationWorkingDays}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      {/* App Bar */}
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: 1400, 
          background: 'linear-gradient(to right,rgb(110, 216, 232) 0%,rgb(111, 222, 239) 100%)',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}
      >
        <Toolbar>
          <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 700 }}>
            Principal Dashboard
          </Typography>
          <IconButton color="inherit" onClick={handleProfileMenuOpen}>
            <PersonIcon />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleProfileMenuClose}
          >
            <MenuItem onClick={handleLogoutClick}>
              <LogoutIcon sx={{ mr: 1 }} />
              Logout
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* Side Drawer */}
      <Drawer
        variant="permanent"
        sx={{
          width: 280,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: 280,
            boxSizing: 'border-box',
            background: "linear-gradient(to bottom, #ffffff 0%, #e6e9f0 100%)",
            borderRight: "1px solid rgba(0,0,0,0.1)",
            boxShadow: "2px 0 5px rgba(0,0,0,0.05)"
          }
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>
            {sidebarMenuItems.map((item, index) => (
              <React.Fragment key={index}>
                {item.subItems ? (
                  <>
                    <ListItem 
                      button 
                      onClick={handleToggleAttendance}
                      sx={{ 
                        '&:hover': { 
                          backgroundColor: 'rgba(0,0,0,0.05)', 
                          borderRadius: 2 
                        } 
                      }}
                    >
                      {item.icon}
                      <ListItemText 
                        primary={item.text} 
                        sx={{ ml: 2, fontWeight: 'medium' }} 
                      />
                      {attendanceOpen ? <ExpandLess /> : <ExpandMore />}
                    </ListItem>
                    <Collapse 
                      in={attendanceOpen} 
                      timeout="auto" 
                      unmountOnExit
                    >
                      <List component="div" disablePadding>
                        {item.subItems.map((subItem, subIndex) => (
                          <ListItem 
                            key={subIndex} 
                            button 
                            sx={{ 
                              pl: 4, 
                              '&:hover': { 
                                backgroundColor: 'rgba(0,0,0,0.05)', 
                                borderRadius: 2 
                              } 
                            }} 
                            onClick={subItem.onClick}
                          >
                            <ListItemText primary={subItem.text} />
                          </ListItem>
                        ))}
                      </List>
                    </Collapse>
                  </>
                ) : (
                  <ListItem 
                    button 
                    onClick={item.onClick}
                    sx={{ 
                      '&:hover': { 
                        backgroundColor: 'rgba(0,0,0,0.05)', 
                        borderRadius: 2 
                      } 
                    }}
                  >
                    {item.icon}
                    <ListItemText 
                      primary={item.text} 
                      sx={{ ml: 2, fontWeight: 'medium' }} 
                    />
                  </ListItem>
                )}
              </React.Fragment>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          p: 3,
          mt: '64px',
          backgroundColor: 'rgb(110, 216, 232) 0%',
          width: 'calc(100% - 280px)'
        }}
      >
        {selectedContent === "dashboard" && renderDashboardContent()}
        {selectedContent === "studentAttendance" && <StudentAttendance />}
        {selectedContent === "personalAttendance" && <PersonalAttendance />}
        {selectedContent === "requestTable" && <RequestTable />}
      </Box>

      {/* Logout Confirmation Dialog */}
      <Dialog open={logoutDialogOpen} onClose={() => setLogoutDialogOpen(false)}>
        <DialogTitle sx={{ fontWeight: 'bold', color: '#1976d2' }}>Confirm Logout</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to logout?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button 
            onClick={() => setLogoutDialogOpen(false)} 
            color="primary" 
            variant="outlined"
            sx={{ mr: 1 }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleLogoutConfirm} 
            color="primary" 
            variant="contained"
          >
            Logout
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Dashboard;