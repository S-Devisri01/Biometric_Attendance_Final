import React, { useEffect, useState, useMemo } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  Box,
  Avatar,
  Tooltip,
  Paper,
  Container,
  Grid,
  useMediaQuery,
  useTheme,
  createTheme,
  ThemeProvider,
} from "@mui/material";
import {
  Dashboard as DashboardIcon,
  AssignmentTurnedIn as AttendanceIcon,
  ExitToApp as LogoutIcon,
  Person as PersonIcon,
  NotificationsActive as LeaveIcon,
  CalendarToday as CalendarIcon,
} from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import axios from "axios";

// Component Imports
import Dashboard from "../components/Student/DashboardComponents";
import LeaveApprovalStatus from "../components/Student/LeaveApprovalStatus";
import LeaveApplicationForm from "../components/Student/LeaveApplication";
import PersonalAttendance from "../components/Staff/PersonalAttendance";

// Custom Theme
const theme = createTheme({
  palette: {
    primary: {
      main: '#3f51b5', // Deep purple
      light: '#7986cb',
      dark: '#303f9f',
    },
    secondary: {
      main: '#ff4081', // Vibrant pink
      light: '#ff80ab',
      dark: '#f50057',
    },
    background: {
      default: '#f5f5f5',
      paper: '#ffffff',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
        },
      },
    },
  },
});

const StudentDashboard = () => {
  // State Management
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [logoutDialogOpen, setLogoutDialogOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [profileAnchorEl, setProfileAnchorEl] = useState(null);

  // Hooks and Navigation
  const navigate = useNavigate();
  const { logout } = useAuth();
  const isDesktop = useMediaQuery(theme.breakpoints.up("md"));
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  // Computed Values
  const emailPrefix = useMemo(() => 
    user?.email ? user.email.split("@")[0] : "Student", 
    [user]
  );

  // Fetch User Data Effect
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get("/api/user/profile");
        setUser(response.data);
        document.title = `SSCEI - ${emailPrefix} Dashboard`;
      } catch (error) {
        console.error("Error fetching user data:", error);
        navigate("/");
      }
    };

    fetchUserData();
  }, [navigate, emailPrefix]);

  // Event Handlers
  const toggleDrawer = () => setDrawerOpen(!drawerOpen);
  const handleTabClick = (tab) => () => {
    setActiveTab(tab);
    if (!isDesktop) setDrawerOpen(false);
  };

  const handleProfileMenuOpen = (event) => {
    setProfileAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setProfileAnchorEl(null);
  };

  const handleLogoutClick = () => setLogoutDialogOpen(true);
  const handleLogoutConfirm = () => {
    logout();
    navigate("/");
  };
  const handleLogoutCancel = () => setLogoutDialogOpen(false);

  // Dashboard Menu Items
  const dashboardMenuItems = [
    {
      label: "Dashboard",
      icon: <DashboardIcon />,
      component: <Dashboard />,
      value: "Dashboard"
    },
    {
      label: "Personal Attendance",
      icon: <AttendanceIcon />,
      component: <PersonalAttendance />,
      value: "PersonalAttendance"
    },
    {
      label: "Leave Status",
      icon: <LeaveIcon />,
      component: <LeaveApprovalStatus />,
      value: "LeaveStatus"
    },
    {
      label: "Leave Request Form",
      icon: <CalendarIcon />,
      component: <LeaveApplicationForm />,
      value: "LeaveRequestForm"
    }
  ];

  return (
    <ThemeProvider theme={theme}>
      <Box 
        sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          minHeight: '100vh', 
          backgroundColor: theme.palette.background.default 
        }}
      >
        {/* App Bar */}
        <AppBar 
          position="fixed" 
          color="primary" 
          sx={{ 
            zIndex: theme.zIndex.drawer + 1,
            boxShadow: '0 4px 6px rgba(0,0,0,0.1)' 
          }}
        >
          <Toolbar>
            <Typography 
              variant="h5" 
              sx={{ 
                flexGrow: 1, 
                fontWeight: 600, 
                textAlign: 'center',
                color: 'white' 
              }}
            >
              SSCEI Student Portal
            </Typography>
          </Toolbar>
        </AppBar>

        <Container 
          maxWidth="xl" 
          sx={{ 
            flexGrow: 1, 
            mt: 10, 
            mb: 4,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'stretch'
          }}
        >
          <Grid 
            container 
            spacing={3} 
            sx={{ 
              width: '100%', 
              maxWidth: 1400,
              margin: 'auto' 
            }}
          >
            {/* Side Navigation */}
            <Grid 
              item 
              xs={12} 
              md={3} 
              sx={{ 
                display: { xs: 'none', md: 'block' } 
              }}
            >
              <Paper 
                elevation={3} 
                sx={{ 
                  height: '100%', 
                  p: 2, 
                  display: 'flex', 
                  flexDirection: 'column' 
                }}
              >
                <Box sx={{ mb: 2 }}>
                  <Typography variant="h6" gutterBottom>
                    Welcome, {emailPrefix}
                  </Typography>
                </Box>

                <List>
                  {dashboardMenuItems.map((item) => (
                    <ListItem
                      key={item.value}
                      button
                      selected={activeTab === item.value}
                      onClick={handleTabClick(item.value)}
                      sx={{
                        borderRadius: 2,
                        mb: 1,
                        '&.Mui-selected': {
                          backgroundColor: theme.palette.primary.light,
                          color: 'white',
                        }
                      }}
                    >
                      <ListItemIcon>{item.icon}</ListItemIcon>
                      <ListItemText primary={item.label} />
                    </ListItem>
                  ))}
                </List>

                <Box sx={{ mt: 'auto' }}>
                  <Button 
                    fullWidth 
                    variant="contained" 
                    color="secondary"
                    startIcon={<LogoutIcon />}
                    onClick={handleLogoutClick}
                  >
                    Logout
                  </Button>
                </Box>
              </Paper>
            </Grid>

            {/* Main Content Area */}
            <Grid item xs={12} md={9}>
              <Paper 
                elevation={3} 
                sx={{ 
                  height: '100%', 
                  p: 3, 
                  overflowY: 'auto' 
                }}
              >
                {dashboardMenuItems.find(item => item.value === activeTab)?.component}
              </Paper>
            </Grid>
          </Grid>
        </Container>

        {/* Logout Dialog */}
        <Dialog
          open={logoutDialogOpen}
          onClose={handleLogoutCancel}
        >
          <DialogTitle>Confirm Logout</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to logout from the SSCEI Student Portal?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleLogoutCancel}>Cancel</Button>
            <Button 
              onClick={handleLogoutConfirm} 
              color="secondary" 
              variant="contained"
            >
              Logout
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </ThemeProvider>
  );
};

export default StudentDashboard;