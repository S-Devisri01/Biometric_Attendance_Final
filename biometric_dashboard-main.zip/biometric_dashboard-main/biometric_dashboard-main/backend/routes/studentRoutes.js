const express = require('express');
const router = express.Router();
const app = express();
const {Op} =require('sequelize');
const sequelize = require('sequelize');
const User = require('../models/Devicelog');
const { where } = require('../config/config');
const { subDays, format } = require("date-fns");




app.post("/attendance-month", async (req, res) => {
  const { UserId, report_type } = req.body;

  // Get current date details
//   const today = new Date();
//   const month = today.getMonth() + 1; // Month is zero-based in JavaScript
//   const year = today.getFullYear();

  // Generate dynamic table name
  const tableName = `devicelogs_8_2024`;
  console.log("Table name:", tableName);

  // Validate input
  if (!UserId) {
    return res.status(400).json({
      status: 400,
      error: "Missing required fields: UserId",
    });
  }

  try {
    // Fetch user data based on UserId
    const user = await User.findAll({
      where: { UserId },
      attributes: ["LogDate","C1"],
    });

    // Ensure user exists
    if (!user || user.length === 0) {
      return res.status(404).json({
        status: 404,
        error: "User not found",
      });
    }

    // Calculate date range based on report_type
    // let prevDate = today;
    // if (report_type === "sDays") {
    //   prevDate = subDays(today, 7);
    // } else if (report_type === "monthly") {
    //   prevDate = subDays(today, 30);
    // } else {
    //   return res.status(400).json({
    //     status: 400,
    //     error: "Invalid report_type. Allowed values: sDays, monthly",
    //   });
    // }

    // (Optional) Logic to query the dynamic table can go here.

    // Respond with success
    res.status(200).json({
      status: 200,
      message: "Data fetched successfully",
      data: {
        user,
        // date_range: { from: prevDate, to: today },
      },
    });
  } catch (err) {
    console.error("Server error:", err);
    res.status(500).json({
      status: 500,
      error: "Server error occurred while fetching attendance data.",
    });
  }
});


// app.post("/addendance-week", async (req, res) => {
//   const { UserId } = req.body;

//   // Generate dynamic table name (customize as needed)
//   const tableName = `devicelogs_8_2024`;
//   console.log("Table name:", tableName);

//   // Validate input
//   if (!UserId) {
//     return res.status(400).json({
//       status: 400,
//       error: "Missing required field: UserId",
//     });
//   }

//   try {
//     // Calculate the last 7 days excluding Sundays
//     const today = new Date();
//     const startDate = subDays(today, 7); // 7 days ago
//     const formattedStartDate = format(startDate, "yyyy-MM-dd");
//     const formattedToday = format(today, "yyyy-MM-dd");

//     // Fetch user data within the date range
//     const user = await User.findAll({
//       where: {
//         UserId,
//         LogDate: {
//           // Between start date and today
//           [Op.between]: [formattedStartDate, formattedToday],
//         },
//       },
//       attributes: ["LogDate", "C1"],
//     });

//     // Filter out Sundays
//     const filteredUserData = user.filter((entry) => {
//       const logDate = new Date(entry.LogDate);
//       const dayOfWeek = logDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
//       return dayOfWeek !== 0; // Exclude Sundays
//     });

//     // Ensure data exists
//     if (filteredUserData.length === 0) {
//       return res.status(404).json({
//         status: 404,
//         error: "No data found for the last 7 days (excluding Sundays).",
//       });
//     }

//     // Respond with success
//     res.status(200).json({
//       status: 200,
//       message: "Data fetched successfully",
//       data: filteredUserData,
//     });
//   } catch (err) {
//     console.error("Server error:", err);
//     res.status(500).json({
//       status: 500,
//       error: "Server error occurred while fetching attendance data.",
//     });
//   }
// });


app.post("/attendance-week", async (req, res) => {
  const { UserId } = req.body;

  // Generate dynamic table name (customize as needed)
  const tableName = `devicelogs_8_2024`;
  console.log("Table name:", tableName);

  // Validate input
  if (!UserId) {
    return res.status(400).json({
      status: 400,
      error: "Missing required field: UserId",
    });
  }

  try {
    // Define the start and end dates
    const startDate = "2024-08-11"; // Start date
    const endDate = "2024-08-18"; // End date

    // Fetch user data within the specified date range
    const user = await User.findAll({
      where: {
        UserId,
        LogDate: {
          // Between start date and end date
          [Op.between]: [startDate, endDate],
        },
      },
      attributes: ["LogDate", "C1"],
    });

    // Filter out Sundays
    const filteredUserData = user.filter((entry) => {
      const logDate = new Date(entry.LogDate);
      const dayOfWeek = logDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
      return dayOfWeek !== 0; // Exclude Sundays
    });

    // Ensure data exists
    if (filteredUserData.length === 0) {
      return res.status(404).json({
        status: 404,
        error:
          "No data found for the specified date range (excluding Sundays).",
      });
    }

    // Respond with success
    res.status(200).json({
      status: 200,
      message: "Data fetched successfully",
      data: filteredUserData,
    });
  } catch (err) {
    console.error("Server error:", err);
    res.status(500).json({
      status: 500,
      error: "Server error occurred while fetching attendance data.",
    });
  }
});



module.exports = app;