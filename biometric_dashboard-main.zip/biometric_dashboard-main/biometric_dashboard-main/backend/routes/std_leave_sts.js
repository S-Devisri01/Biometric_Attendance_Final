const express =require('express');
const devicelog= require("../config/config");
const Request = require('../models/Leave')
const app = express();


// Get Request form status based on id
// app.post('/leavests',async (req,res)=>{
//     const {sin_number,student_name,class_advisor_approval,hod_approval,
//         principal_approval,placement_officer_approval}=req.body;
//     try{
//         const sts = await Request.findOne({
//             where:{sin_number},

//         });
//         const responseData = {
//             status:200,
//             message:"leave sts got for gvn sin",
//             student_name: sts.student_name,
//             class_advisor_approval : sts.class_advisor_approval,
//             hod_approval: sts.hod_approval,
//             principal_approval:sts.principal_approval,
//             placement_officer_approval: sts.placement_officer_approval
//         }
//         res.json(responseData);
//     }catch(err){
        
//         res.status(500).json({error:"db error"})
//         console.error(err);
//     }
// })


app.post('/leavests', async (req, res) => {
    const { sin_number } = req.body;
    
    try {
        const sts = await Request.findOne({ where: { sin_number } });

        if (!sts) {
            return res.status(404).json({ error: "Request not found" });
        }

        console.log("Fetched PDF Data Length:", sts.pdf_path ? sts.pdf_path.length : "NULL");

        const responseData = {
            status: 200,
            message: "Leave status retrieved successfully",
            student_name: sts.student_name,
            class_advisor_approval: sts.class_advisor_approval,
            hod_approval: sts.hod_approval,
            principal_approval: sts.principal_approval,
            placement_officer_approval: sts.placement_officer_approval, pdf_data: sts.pdf_path ? sts.pdf_path.toString('base64') : null // ✅ Converts PDF to Base64
            // pdf_present: !!sts.pdf_path // ✅ Check if PDF data exists
        };

        res.json(responseData);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Database error" });
    }
});


module.exports=app;